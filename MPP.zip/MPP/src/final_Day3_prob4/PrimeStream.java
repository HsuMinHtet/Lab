package final_Day3_prob4;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PrimeStream {

	private void printFirstNPrimes(long n) {
		List<Integer> primes = Stream.iterate(2, PrimeStream::getPrime).limit(n).collect(Collectors.toList());
		System.out.println(primes);

		System.out.println(Stream.iterate(2, x -> getPrime(x)).limit(n).map(Object::toString)
				.collect(Collectors.joining(" ,", "", ".")));
	}

	public static int getPrime(int number) {
		int i = 0;

		if (number < 2)
			return 2;
		else
			number++;
		for (i = 2; i < number; i++) {
			if (i != number && number % i == 0) {
				number++;
				i = 2;
			}

		}
		if (i == number)
			return number;
		return i;
	}

	public static boolean isPrime(Integer n) {
		int i=2;
		if(n<2) return false;
		for(i=2;i<n;i++) {
			if(i!=n && n%i==0)
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		PrimeStream ps = new PrimeStream(); // PrimeStream is enclosing class
		ps.printFirstNPrimes(10);
		System.out.println("====");
		ps.printFirstNPrimes(5);
		
		System.out.println("Is Prime");
		Stream.iterate(2,n->n+1).filter(PrimeStream::isPrime).limit(5).forEach(System.out::print);
		//Stream.iterate(2,n->n+1).filter(n -> isPrime(n)).limit(5).forEach(System.out::print);
	}
}
