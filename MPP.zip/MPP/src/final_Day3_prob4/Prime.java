package final_Day3_prob4;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Prime {
	public static void main(String[] args) {
		List<Integer> primes = Stream.iterate(2, x -> isPrime(x + 1)).limit(20).collect(Collectors.toList());
		System.out.println(primes);
	}

	public static int isPrime(int number) {
		int i = 0;
		for (i = 2; i < number; i++) {
			if (i != number && number % i == 0) {
				number++;
				i = 2;
			}

		}
		if (i == number)
			return number;
		return i;
	}
}
