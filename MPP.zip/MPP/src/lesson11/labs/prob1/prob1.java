package lesson11.labs.prob1;

import java.util.*;

public class prob1 {
	
	public static void main(String[] args) {
		//a
		List<Integer> ints = new ArrayList<>();
		ints.add(1);
		ints.add(2);
		List<Number> nums = ints; //Compiler Error (Not Covariant)
		nums.add(3.14);

		//b
		List<Integer> ints1 = new ArrayList<>();
		ints.add(1);
		ints.add(2);
		List<? extends Number> nums1 = ints1;
		nums.add(3.14);	//  extends bounded Wildcard (can be gotten but can't added)
		
	}

}
