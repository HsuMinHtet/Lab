package lesson11.exercise_4;

import java.util.Arrays;
import java.util.List;

public class Add_Get {
	
	public static <T> void copy(List<? super T>destination, List<? extends T>source) {
		for(int i=0; i<source.size(); i++ ) {
			destination.set(i,source.get(i));
		}
	} 

	public static void main(String[] args) {
		List<Object> obList= Arrays.asList(2,3.14,"four");
		List<Integer> intList= Arrays.asList(5,6);
		
		copy(obList	, intList);
		System.out.println(obList.toString());
	
		
	}

}
