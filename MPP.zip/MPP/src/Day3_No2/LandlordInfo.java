package Day3_No2;

import java.util.*;

public class LandlordInfo {

	private List<Building> buildingList;

	public LandlordInfo() {
		buildingList = new ArrayList<Building>();
	}

	public void addBuilding(int cost, int buildNo) {
		Building b = new Building(cost, buildNo);
		buildingList.add(b);
	}

	public List<Building> getBuildings() {
		return buildingList;
	}

	public int calcProfits() {
		int total_Rent = 0;
		int profit = 0;
		int total_Cost=0;
		for (Building b : buildingList) {
			total_Cost+= b.getCost();
			ArrayList<Appartment> appList = (ArrayList<Appartment>) b.getApprtmentList();
			for (Appartment a : appList) {
				total_Rent += a.getRent();
			}//7675
		}
		//System.out.println(total_Cost+"&"+total_Rent);
		
		return total_Rent-total_Cost;
	}
}
