package quiz_No2;

public class Account {
	private String accountId;
	private Customer cust;

	// package level
	Account(String accountId, Customer cust) {
		this.accountId=accountId;
		this.cust=cust;
	}
	
	public String getAccountId() {
		return accountId;
	}

	public Customer getCust() {
		return cust;
	}

	public String toString() {
		return "Account ID: "+ accountId;
	}
	
}
