package quiz_No2;

public class Customer {
	private String name;
	private Account acct;
	
	public Customer(String name, String accountID) {
		this.name=name;
		this.acct= new Account(accountID,this);
	}

	public String getName() {
		return name;
	}
	public Account getAcct() {
		return acct;
	}
	
}
