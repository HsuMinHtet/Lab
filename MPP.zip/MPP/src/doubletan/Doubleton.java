package doubletan;

public class Doubleton {
	//public static int countInstances = 0;
	private static Doubleton[] instance = new Doubleton[2];

	private Doubleton() {
		//++countInstances;
	}

	public static Doubleton getInstance(int i) {
		if (i < 0 || i >= 2)
			return null;
		if (instance[i] == null) 
			instance[i] = new Doubleton();
		return instance[i];
	}

	public static void main(String[] args) {
		for (int i = 0; i < 3; ++i) {
			getInstance(i);
			System.out.println(getInstance(i));
		}
		//System.out.println(MySingleton.countInstances);
	}
}
