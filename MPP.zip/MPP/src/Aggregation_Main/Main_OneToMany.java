package Aggregation_Main;

import Exercise_1_Many_Bi.*;


public class Main_OneToMany {

	public static void main(String[] args) {
		
		ShoppingCart cart1= ShoppingCartItemFactory.createShoppingCart("SH_001");
		cart1.addItem("Item_01");
		cart1.addItem("Item_02");
		cart1.addItem("Item_03");
		cart1.addItem("Item_04");
		cart1.addItem("Item_05");
		
		ShoppingCart cart2= ShoppingCartItemFactory.createShoppingCart("SH_002");
		cart2.addItem("Item_11");
		cart2.addItem("Item_12");
		cart2.addItem("Item_13");
		cart2.addItem("Item_14");
		cart2.addItem("Item_15");
		System.out.println(cart1.getList().toString());
		System.out.println(cart2.getList().toString());

	}

}
