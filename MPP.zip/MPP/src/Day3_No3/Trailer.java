package Day3_No3;


public class Trailer extends Properties{
	private static final double RENT = 500;
	private Address address;
	public Address getAddress() {
		return address;
	}
	public Trailer(Address address) {
		this.address = address;
	}
	@Override
	public double computeRent(){
		return RENT;
	}
	
}
