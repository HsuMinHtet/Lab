package Day3_No3;

public abstract class Properties {

	public abstract double computeRent();
}
