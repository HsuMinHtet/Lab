package final_Day1_getClassTesting;

public class ClassB extends ClassA{

}
