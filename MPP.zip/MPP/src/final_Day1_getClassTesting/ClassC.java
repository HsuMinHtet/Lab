package final_Day1_getClassTesting;

public class ClassC extends ClassB{

}
