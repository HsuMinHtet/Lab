package final_Day1_getClassTesting;

public class ClassA {

}
