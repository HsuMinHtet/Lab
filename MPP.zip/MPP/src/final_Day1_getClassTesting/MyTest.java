package final_Day1_getClassTesting;

public class MyTest {

	public static void main(String[] args) {
		ClassA a = new ClassA();
		ClassB b = new ClassB();
		ClassA c = new ClassC();
		ClassA d = new ClassB();
		System.out.println(a.getClass().hashCode());
		System.out.println(b.getClass().hashCode());
		if(c instanceof ClassB)
			System.out.print("I am true");
		else
			System.out.print("I am false");
	}

}
