package final_Day1_Exercise_1;

public class MyClass {
	

	public static void main(String[] args) {
		System.out.println(Constants.COMPANY.s);
		System.out.println(Constants.SALES_TARGET.num);
		
		System.out.println(Constant_Object.COMPANY.val);
		//char[] s= (char[]) Constant_Object.COMPANY.val;
		
		System.out.println(Constant_Object.SALES_TARGET.val);
		int num= (int) Constant_Object.SALES_TARGET.val;
	
	}

}
