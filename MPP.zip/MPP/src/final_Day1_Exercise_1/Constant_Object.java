package final_Day1_Exercise_1;

public enum Constant_Object {
	COMPANY("Microsoft"),
	SALES_TARGET(2000000);
	Object val;

	private Constant_Object(Object val) {
		this.val = val;
	}

	public Object getVal() {
		return val;
	}
	
}
