package final_Day1_Exercise_1;

public enum Constants {
	COMPANY("Microsoft"),
	SALES_TARGET(2000000);
	String s;
	double num;
	private Constants(String s) {
		this.s = s;
	}
	private Constants(double num) {
		this.num = num;
	}
	public double num() {
		return num;
	}
	public String s() {
		return s;
	}
	
}
