package day10_exercise;

import java.util.*;

public class exercise {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		//List<Number> num= list;
		//num.add(3.14);
		System.out.println(list);
	}

}
