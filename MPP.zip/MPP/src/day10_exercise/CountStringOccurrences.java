package day10_exercise;

import java.util.stream.Stream;

public class CountStringOccurrences {
	public static <T> int countOccurrences(T[] arr, T target) {
		int count = 0;
		if (target == null) {
			for (T item : arr) {
				if (item == null) {
					count++;
				}
			}
		} else {
			for (T item : arr) {
				if (target.equals(item)) {
					count++;
				}
			}
		}
		return count;
	}

	public static <T> int countOccurrences_Stream(T[] arr, T target) {
		return (int) Stream.of(arr).filter(item -> (item==null && target==null) || item.equals(target)).count();
	}

	public static void main(String[] args) {
		Integer[] arr= new Integer[3];
		arr[0]=1;
		arr[1]=3;
		arr[2]=5;
		
		Integer num =3;
		System.out.println(countOccurrences(arr,num)); 	

	}

}
