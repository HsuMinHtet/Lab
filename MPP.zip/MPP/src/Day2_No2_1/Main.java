package Day2_No2_1;
/*
 * Bi-Directional
 */
public class Main {

	public static void main(String[] args) {
		Student s1 = new Student("Jerry");
		s1.getGrade().addGrade(new Grade("A"));
		s1.getGrade().addGrade(new Grade("A+"));
		s1.getGrade().addGrade(new Grade("A+"));
		s1.getGrade().addGrade(new Grade("B+"));
		
		System.out.println("Studnet : "+s1+" has the following grade"+"\n"+s1.getGrade().getGades());
		//bi-directional 
		System.out.println("Name : "+ s1.getGrade().getOwner() );
		
	}

}
