package final_Day2_prob6;

import java.util.Collections;
import java.util.Comparator;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class exercise {

	// (String x) -> x.toUpperCase()
	// type: Class::instanceMethod
	Function<String, String> upper1 = (x) -> x.toUpperCase();
	Function<String, String> upper2 = String::toUpperCase;

	// A. (Employee e)-> e.getName()
	Function<Employee, String> name1 = (e) -> e.getName();
	Function<Employee, String> name2 = Employee::getName;

	// B. (Employee e, String s)->e.setName(s)
	BiConsumer<Employee, String> setName1 = (e, s) -> e.setName(s);
	BiConsumer<Employee, String> setName2 = Employee::setName;

	// C. (String s1, String s2)-> s1.compareTo(s2);
	Comparator<String> compare1 = (s1, s2) -> s1.compareTo(s2);
	Comparator<String> compare2 = String::compareTo;

	// D. (Integer x, Integer y)-> Math.pow(x,y)
	BiFunction<Integer, Integer, Double> power1 = (x, y) -> Math.pow(x, y);
	BiFunction<Integer, Integer, Double> power2 = Math::pow;

	// E. (Apple a) -> a.getWeight()
	Function<Apple, Double> weight1 = (a) -> a.getWeight();
	Function<Apple, Double> weight2 = Apple::getWeight;

	// F. (String x) -> Integer.parseInt(x)
	Function<String, Integer> value1 = (x) -> Integer.parseInt(x);
	Function<String, Integer> value2 = Integer::parseInt;

	// G. EmployeeNameComparator comp= new EmployeeNameComparator();
	// (Employee e1, Employee e2)->comp.compare(e1,e2)
	EmployeeNameComparator comp = new EmployeeNameComparator();
	Comparator<Employee> nameCompare1 = (e1, e2) -> comp.compare(e1, e2);
	Comparator<Employee> nameCompare2 = comp::compare;
	
	Comparator<Integer> com_Long= Integer::compareTo;
	
	class myComparator implements Comparator<Integer>{

		@Override
		public int compare(Integer o1, Integer o2) {
			// TODO Auto-generated method stub
			return o1.compareTo(o2);
		}
		
	}
	
	class mySupplier implements Supplier<Double>{

		@Override
		public Double get() {
			// TODO Auto-generated method stub
			return Math.random();
		}
		
	}

	public void evaluator() {
		Employee e1 = new Employee();
		Employee e2 = new Employee();
		System.out.println(upper2.apply("hello"));
		setName1.accept(e1, "Bob");
		setName1.accept(e2, "Bob");
		System.out.println(name2.apply(e1));
		System.out.println("Compare To:" + compare1.compare("Bob", "Bob"));
		System.out.println("Compare To:" + compare2.compare("Thinkk", "Think"));

		System.out.println("Math Power: " + power1.apply(2, 3));
		System.out.println("Math Power: " + power2.apply(3, 3));

		Apple a = new Apple(2.2);
		System.out.println("Apple" + weight1.apply(a));

		System.out.println("Integer Parse Int: " + value1.apply("50"));

		System.out.println("Compare: " + nameCompare1.compare(e1, e2));
		
		System.out.println("inner class: "+ new mySupplier().get());
		
		System.out.println("Inner 2: "+ new myComparator().compare(20, 23));
	}

	public static void main(String[] args) {
		exercise e = new exercise();
		e.evaluator();

	}

}