package final_Day2_prob6;

public class Apple {
	private double weight;
	public Apple(double weight) {
		this.weight=weight;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}

}
