package final_Day2_prob6;

import java.util.Comparator;

public class EmployeeNameComparator implements  Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		String name1= o2.getName();
		return o1.getName().compareTo(name1);
	}

}
