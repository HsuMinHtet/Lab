package quizFinal;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

public class Main {
	
	public static BiFunction<List<Customer>, String, List<String>> getCustomer = 
			(list,city)->{
				return list.stream().filter(c->
				c.getCity().equals(city))
						.map(c->c.getName()).collect(Collectors.toList());
			};
	


	public static void main(String[] args) {
		List<Customer> list= new ArrayList<Customer>();
		list.add(new Customer(1, "Tom", "London"));
		list.add(new Customer(1, "Bob", "London"));
		list.add(new Customer(1, "Joe", "Burlinton"));
		list.add(new Customer(1, "Adam", "Fairfield"));
	
		System.out.println(Main.getCustomer.apply(list, "London"));
		System.out.println(Main.getCustomer.apply(list, "Burlinton"));
	}

}
