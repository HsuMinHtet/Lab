package Day4_5;

public class SavingsAccount extends Account{
	private double interestRate;
	private double balance;
	private String acctId;
	
	public SavingsAccount(String acctId, double interestRate, double startBalance) {
		this.acctId=acctId;
		this.balance=startBalance;
		this.interestRate=interestRate;
	}

	@Override
	public String getAccountID() {
		return this.acctId;
	}

	@Override
	public double getBalance() {
		return this.balance;
	}

	@Override
	public double computeUpdatedBalance() {
		return balance+(balance*interestRate);
	}

}
