package Day4_5;

import java.util.*;

public class Employee {
	private String name;
	private List<Account> list;
	
	public Employee(String name) {
		this.name = name;
		list= new ArrayList<Account>();
	}
	
	public void addAccount(Account acct) {
		list.add(acct);
	}

	public String getName() {
		return name;
	}

	public double computeUpdatedBalanceSum() {
		double totalUpdateBalance=0.0;
		for(Account a: list) {
			totalUpdateBalance+=a.computeUpdatedBalance();
		}
		return totalUpdateBalance;
	}
}
