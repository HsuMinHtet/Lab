package Exercise_1_Many_Bi;

public class ShoppingCartItemFactory {
	public static ShoppingCart createShoppingCart(String cart_id) {
		ShoppingCart cart= new ShoppingCart(cart_id);
		return cart;	
	}
}
