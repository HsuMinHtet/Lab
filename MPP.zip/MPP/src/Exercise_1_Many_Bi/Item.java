package Exercise_1_Many_Bi;

public class Item {
	private String name;
	private ShoppingCart cart;

	// package level
	Item(ShoppingCart cart, String name) {
		this.cart = cart;
		this.name = name;
	}

	@Override
	public String toString() {
		return "\nShopping Cart ID: " + cart.getCart_id() + "\nItem Name: " + name.toString();
	}

}
