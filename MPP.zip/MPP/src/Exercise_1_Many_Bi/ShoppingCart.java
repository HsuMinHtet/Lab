package Exercise_1_Many_Bi;

import java.util.*;

public class ShoppingCart {
	private List<Item> list;
	private String cart_id;

	//package level
	ShoppingCart(String cart_id) {
		this.cart_id=cart_id;
		list= new ArrayList<Item>();
	}

	
	public List<Item> getList() {
		return list;
	}

	public void addItem(String name) {
		Item item= new Item(this,name);
		list.add(item);
	}

	public String getCart_id() {
		return cart_id;
	}

}
