package final_Day1_Exercise;

public interface StringList {
	void add(String s); 
	String get(int i);
}
