package final_Day1_Exercise;

public class MyStringList implements StringList {

	@Override
	public void add(String s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String get(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
