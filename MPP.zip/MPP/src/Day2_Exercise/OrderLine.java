package Day2_Exercise;

public class OrderLine {

	public OrderLine() {
		// TODO Auto-generated constructor stub
	}

}
