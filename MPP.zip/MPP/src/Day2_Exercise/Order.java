package Day2_Exercise;

public class Order {

	public Order() {
		// TODO Auto-generated constructor stub
	}

}
