package lesson9.labs.prob7;

import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;

import lesson9.labs.prob3.Employee;

public class Main {

	public static void main(String[] args) {
		List<Integer> intList = Arrays.asList(4, 5, -2, 0, -3, -1, -5, -4);
		// expected output: [0, -1, -2, -3, -4, 4, -5, 5]
		System.out.println("--->");
		System.out.println(intList.stream()
				.sorted(Comparator.comparing(Math::abs))
				.map(Object::toString)
				.collect(Collectors.joining(" ,"))
				);
		System.out.println("--->");
		ordering1(intList);
		List<String> stringList = Arrays.asList("cba", "efg", "doe", "fie", "set");
		// expected output: [cba, fie, doe, efg, set]
		// reverse each string : abc,gfe,eod,eif,tes
		// order: abc,eif,eod,efg,tes-> cba,fie,doe,set
		System.out.println(stringList.stream()
				.sorted(Comparator.comparing(x-> new StringBuffer(x).reverse()))
				.collect(Collectors.joining(" ,"))
				
				);
		ordering2(stringList);

	}

	// Orders the integers according to this pattern:
	// 0, -1, 1, -2, 2, -3, 3, . . .
	// Using this ordering, this method sorts the list as part of
	// a stream pipeline, and prints to the console
	public static void ordering1(List<Integer> list) {
		List<Integer> intList = list.stream().sorted(Comparator.comparingInt(Math::abs)).collect(Collectors.toList());
		System.out.println(intList);
		
	}

	// Orders words by first reversing each and comparing
	// in the usual way. So
	// cba precedes bed
	// since
	// cba.reverse() precedes bed.reverse()
	// in the usual ordering
	// Using this ordering, this method sorts the list as part of
	// a stream pipeline, and prints to the console
	public static void ordering2(List<String> words) {

		System.out.println(words.stream().sorted(Comparator.comparing(s -> new StringBuffer(s).reverse().toString()))

				.collect(Collectors.toList()));

	}


}
