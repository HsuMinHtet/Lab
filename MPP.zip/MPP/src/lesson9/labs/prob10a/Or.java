package lesson9.labs.prob10a;

import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Or {

	public static void main(String[] args) {
		List<Simple> list = Arrays.asList(new Simple(false), new Simple(false), new Simple(true));
		Stream<String> stringStream= Stream.of("Bill","Thomas","Mary");
		Stream<Integer> myIntStream= Stream.of(1,2,3,4,5);
		//a
		System.out.println(someSimpleIsTrue_stream(list));
		System.out.println(someSimpleIsTrue(list));
		//b
		stringPrint(stringStream);
		//c
		minmaxInteger(myIntStream);
	}
	
	public static boolean someSimpleIsTrue(List<Simple> list) {
		boolean accum = false;			
		for(Simple s: list) {
			accum = accum || s.flag;
		}
		return accum;
	}
	public static boolean someSimpleIsTrue_stream(List<Simple> list) {
		return list.stream().map(x->x.flag).reduce(false,(x,y)->x||y); //true
	}
	
	public static void stringPrint(Stream<String> stringStream) {
		String s= stringStream.collect(Collectors.joining(", "));
		System.out.println(s);
	}
	public static void minmaxInteger(Stream<Integer> myIntStream) {
		IntSummaryStatistics summary= myIntStream.collect(Collectors.summarizingInt(x->x));
		System.out.println("Min: "+ summary.getMin());
		System.out.println("Max: "+ summary.getMax());
		
		Stream<Integer> myIntStream1= Stream.of(1,2,3,4,5);
		Integer max= myIntStream1.min(Comparator.comparing(x->x)).orElse(0);
		//int max= myIntStream1.mapToInt(Integer::intValue).max().orElse(0);
		//int min= myIntStream1.mapToInt(Integer::intValue).min().orElse(0);
		System.out.println(max);

	}
}
