package lesson9.labs.prob9;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Square {

	public static void main(String[] args) {

		printSquares(4);
		/*
		 * for(int i=1;i<4;i++) { int num=i*i;
		 * System.out.println(calculateNextSquare(num)); }
		 */
	}

	public static void printSquares(int num) {
	//Stream.iterate(1, Square::calculateNextSquare).limit(num).forEach(n -> System.out.print(n + (n == 16 ? "" : ", ")));
	String s= Stream.iterate(1, x-> calculateNextSquare(x)).limit(num).map(Object::toString).collect(Collectors.joining(",", "", "."));
	System.out.println(s);
	}

	public static Integer calculateNextSquare(Integer previousSquare) {
		return (int) Math.pow((int) Math.sqrt(previousSquare) + 1, 2);

	}
}
