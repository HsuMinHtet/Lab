package lesson9.labs.prob11b;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LambdaLibrary {

	public static final Function<Employee, String> fullName = e -> {
		String fullName = e.getFirstName() + " " + e.getLastName();
		return fullName;
	};
	
	public static final TriFunction<List<Employee>, Integer, String, Stream<Employee>> TRI_FUNCTION = (list, Amt, letter) -> list
			.stream().filter(e -> e.getSalary() > Amt)
			.filter(e -> e.getLastName().charAt(0) > letter.charAt(0) && e.getLastName().charAt(0) <= 'Z');
	
	public static String getFullName(List<Employee> list, Integer amt ,String s) {
		return TRI_FUNCTION.apply(list, amt, s)
				.map(e->LambdaLibrary.fullName.apply(e)).collect(Collectors.joining(", "));
	}
 
}
