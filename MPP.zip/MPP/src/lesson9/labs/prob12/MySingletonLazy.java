package lesson9.labs.prob12;

import java.util.Optional;

public class MySingletonLazy {
	private static MySingletonLazy instance=null;

	private MySingletonLazy() {}
	
	public static MySingletonLazy getInstance() {
		return Optional.ofNullable(instance)
				.orElseGet(MySingletonLazy::new);
				//.orElseGet(()->{ instance=new MySingletonLazy();
				//return instance;});
	}
	public static void main(String[] args) {
		MySingletonLazy lazy1= MySingletonLazy.getInstance();
		System.out.println("Instance :"+ lazy1.getClass().toString());
		MySingletonLazy lazy2= MySingletonLazy.getInstance();
		System.out.println("Instance :"+ lazy2.getClass().toString());
		if(lazy1.equals(lazy2))
			System.out.println("True");
	}

}
