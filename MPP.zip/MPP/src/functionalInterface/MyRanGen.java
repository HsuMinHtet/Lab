package functionalInterface;

import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class MyRanGen implements MyIface {

	public static void main(String[] args) {
		MyIface mrg = new MyRanGen();
		System.out.println(mrg.produce());
		System.out.println("Odd: "+ MyRanGen.odd.apply(3));
		System.out.println("is Odd: "+MyRanGen.isOdd.test(4));
		class myRan implements Supplier{

			@Override
			public Double get() {
				// TODO Auto-generated method stub
				return Math.random();
			}
			
		}
		myRan m =new myRan();
		System.out.println(m.get());
		
		
	}
	
	public static Predicate<Integer> isOdd= (x)->x%2!=0;
	
	public static Function<Integer,Boolean> odd = (x) -> {
		if (x % 2 != 0)
			return true;
		else
			return false;
	};

	@Override
	public double produce() {
		return Math.random();
	}

}
