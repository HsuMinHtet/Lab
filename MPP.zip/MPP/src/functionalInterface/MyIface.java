package functionalInterface;
@FunctionalInterface
public interface MyIface {
	double produce();
	String toString();
}
