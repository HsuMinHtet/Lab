package Day4_3;

enum Tax {
	FICA(0.23), STATE(0.05), LOCAL(0.001), MEDICARE(0.003), SOCIAL_SECURITY(0.75);

	private double value;

	Tax(double d) {
		// TODO Auto-generated constructor stub
	}

	public double getValue() {
		return value;
	}
	// 23%,5%,1%,3%,7.5%
};
