package final_Day3_exercise;

public class MyTesting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyEnum.FIRST.execute();
	}
}




