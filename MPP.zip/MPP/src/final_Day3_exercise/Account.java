package final_Day3_exercise;

public class Account {
	private String ownerName;
	private int balance;
	private int accId;
	public Account(String ownerName, int balance, int accId) {
		super();
		this.ownerName = ownerName;
		this.balance = balance;
		this.accId = accId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	@Override
	public String toString() {
		return "[" + ownerName + ", " + balance+"]";
	}
}


