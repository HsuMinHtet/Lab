package final_Day3_exercise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import lesson9.labs.prob2.ExamData;

public class MyMain {

	static enum SortMethod {
		BYNAME, BYID
	};

	// Comparators are unaware of the value in method

	public static void main(String[] args) {
		Account acc1 = new Account("Joe", 150000, 1);
		Account acc2 = new Account("Tim", 100000, 2);
		List<Account> accounts = new ArrayList<Account>();
		accounts.add(acc1);
		accounts.add(acc2);

		List<Account> accounts1 = new ArrayList<Account>();
		accounts.add(acc1);
		accounts.add(acc2);
		// sorted
		List<Account> sorted = accounts.stream()
				.sorted(Comparator.comparing((Account a) -> a.getBalance()).thenComparing(a -> a.getOwnerName()))
				.collect(Collectors.toList());
		List<Account> simple = accounts.stream().sorted(Comparator.comparing((Account a) -> a.getOwnerName()))
				.collect(Collectors.toList());

		System.out.println(sorted);
		System.out.println("");

		List<ExamData> data = new ArrayList<ExamData>() {
			{
				add(new ExamData("G", 91.3));
				add(new ExamData("T", 88.9));
				add(new ExamData("Rick", 80.0));
				add(new ExamData("Harold", 90.8));
				add(new ExamData("I", 60.9));
				add(new ExamData("A", 77.0));
				add(new ExamData("S", 87.3));
				add(new ExamData("P", 99.1));
				add(new ExamData("Alex", 84.0));
			}
		};

		// Stream Concat
		// List<Account> accList=
		Stream.concat(accounts.stream(), accounts1.stream()).collect(Collectors.toList()).forEach(System.out::print);
		System.out.println("\n------------");

		// SummaryStatistics
		DoubleSummaryStatistics summary = data.stream().collect(Collectors.summarizingDouble(x -> x.getScore()));
		System.out.println(summary);
		System.out.println("Max :" + summary.getMax());
		System.out.println("Min :" + summary.getMin());
		System.out.println("Sum :" + summary.getSum());
		System.out.println("Avg :" + summary.getAverage());
		System.out.println("");

		// joining
		System.out.println(accounts.stream().map(Account::toString).collect(Collectors.joining()));
		System.out.println(accounts.stream().map(x -> x.toString()).collect(Collectors.joining(" ,")));
		System.out.println(accounts.stream().map(Object::toString).collect(Collectors.joining(" ,", "", ".")));

		// to map for creating Map
		Map<Integer, String> map1 = accounts.stream()
				.collect(Collectors.toMap(Account::getAccId, Account::getOwnerName));
		System.out.println(map1);
		Map<Integer, Account> map2 = accounts.stream()
				.collect(Collectors.toMap(a -> a.getAccId(), Function.identity()));
		System.out.println(map2);
		Map<Integer, Account> map3 = accounts.stream().collect(Collectors.toMap(a -> a.getAccId(), a -> a));
		System.out.println(map3);
		System.out.println("");

		// Reduce
		Integer i = Stream.of(1, 2, 3, 4, 5).reduce(Integer::sum).get();
		System.out.println(i);
		// testing reduce
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
		// add
		Integer add1 = list.stream().reduce(0, (x, y) -> x + y);
		Integer add2 = list.parallelStream().reduce(0, (x, y) -> x + y);
		System.out.println("Add");
		System.out.println(add1 + " " + add2);
		// diff
		Integer diff1 = list.stream().reduce(0, (x, y) -> x - y);
		Integer diff2 = list.parallelStream().reduce(0, (x, y) -> x - y);
		System.out.println("Diff");
		System.out.println(diff1 + " " + diff2);
		// exe9.4
		Stream<String> strings = Stream.of("A", "good", "day", "to", "write", "some", "Java");
		// Optional<String> s = strings.reduce((x, y) -> (x + " " + y));
		// String str1= strings.reduce("",(x,y)->x+" ,"+y).trim();
		// System.out.println("Test :"+str1);
		// System.out.println(s.toString());
		// System.out.println("Testing for reduce :" + (s.isPresent() ? s.get() : "no
		// data"));
		String str2 = strings.reduce("", (x, y) -> new StringBuilder(x).append(" " + y).toString()).trim();
		System.out.println(str2);
		System.out.println(".........");

		// primitive stream
		IntStream ints = IntStream.of(1, 2, 3, 4, 5);
		IntStream generateInt = IntStream.generate(() -> 1);
		IntStream iterateInt = IntStream.range(0, 100);
		Stream<Integer> inteNum = IntStream.iterate(0, x -> x + 1).boxed();

	}
}
