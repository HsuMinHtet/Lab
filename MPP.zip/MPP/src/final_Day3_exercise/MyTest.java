package final_Day3_exercise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class MyTest {

	public static void main(String[] args) {
		List<String> a1 = Arrays.asList("Hello", "there");
		List<String> a2 = Arrays.asList("good", "again");
		Stream<List<String>> s= Stream.of(a1,a2);

		ArrayList<String> arr_list = (ArrayList<String>) s.reduce(new ArrayList<String>(), (l1, l2) -> {
			l1.addAll(l2);
			return l1;
		});

		//System.out.println(arr_list.toString());

	}

}
