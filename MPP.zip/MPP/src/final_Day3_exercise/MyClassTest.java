package final_Day3_exercise;

public class MyClassTest {
	
		int myMethod(int x) {
			return x * x;
		}
	
}
