package final_Day3_exercise;

public enum MyEnum1 {
	FIRST, SECOND;

}
