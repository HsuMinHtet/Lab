package final_Day3_exercise;

public class ExamData {
	private String name;
	private Double score;
	public ExamData(String name, Double score) {
		super();
		this.name = name;
		this.score = score;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
	
	@Override
	public String toString() {
		return "\n\nExam Data: \n" 
		  +  " name: " + name + "\n"
		  +  " score: \n" 
		  +  " " + score;
	}
}
