package final_Day3_exercise;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Skip_Limit {

	public static void main(String[] args) {
		List<Integer> list = Stream.iterate(1, n -> n + 2).limit(4).collect(Collectors.toList());
		System.out.println(list);

		List<Integer> list1 = Stream.iterate(1, n -> n + 2).limit(8).skip(4).collect(Collectors.toList());
		System.out.println(list1);

		Stream<Integer> stream = Stream.iterate(0, n -> n + 2).limit(5).skip(2);
		Stream<Integer> stream1 = Stream.iterate(0, n -> n + 2).skip(2).limit(5);
		stream.collect(Collectors.toList()).forEach(System.out::print);
		System.out.println("");
		stream1.collect(Collectors.toList()).forEach(System.out::print);

		Stream<String> s1 = Stream.of("Test", "ing");
		Stream<String> s2 = Stream.of("Con", "cat");
		Stream<String> result = Stream.concat(s1, s2);
		result.collect(Collectors.toList()).forEach(System.out::print);
		System.out.println("---------------");
		Stream.of(1,2,3,4).flatMap(n->Stream.of(n,n*n)).forEach(x->System.out.print(x+(x!=null? ",":".")));
	
		//Fibo
		int n = 3; // Adjust this to specify how many Fibonacci numbers you want

        String fibonacciStream = Stream
        		.iterate(new Integer[]{0, 1}, fib -> new Integer[]{fib[1], fib[0] + fib[1]})
                .map(l -> l[0])
                .limit(n).map(Object::toString)
                .collect(Collectors.joining(" ,"));
        System.out.println("\nFibo: "+fibonacciStream);
        //fibonacciStream.forEach(System.out::print);
	
        
        //Factorial
        int num = 5; // Adjust this to specify how many factorials you want
        Stream<BigInteger> factorialStream = Stream.iterate(new BigInteger[]{BigInteger.ONE, BigInteger.ONE},
                pair -> new BigInteger[]{pair[0].add(BigInteger.ONE), pair[0].multiply(pair[1])})
                .limit(num)
                .map(pair -> pair[1]);
        System.out.println("\nFactorial: ");
        factorialStream.forEach(System.out::println);
        
	}

}
