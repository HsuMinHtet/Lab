package final_Day3_exercise;

	enum MyEnum  {
			FIRST,SECOND;
			void execute() {
				System.out.println(myMethod(3));
			}
		}

	class Main {
		public static void main(String[] args) {
			MyEnum.FIRST.execute();
		}
	}

	class MyClass {
		 int myMethod(int x) {
		 return x * x;
		 }
	}
