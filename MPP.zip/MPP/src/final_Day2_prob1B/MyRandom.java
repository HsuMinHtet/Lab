package final_Day2_prob1B;

import java.util.function.Supplier;

public class MyRandom {
	private MySupplier mySup = new MySupplier();
	public static void main(String[] args) {
		Supplier<Double> sup = Math::random;
		System.out.println(sup.get());
		
		MyRandom myRam= new MyRandom();
		System.out.println(myRam.mySup.get());

	}
	class MySupplier implements Supplier<Double>{

		@Override
		public Double get() {
			return Math.random();
		}
		
	}

}
