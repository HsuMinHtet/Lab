package Day2_No2_2;

import java.util.*;

public class OrderLine {
	private Order order;
	//private int num;
	private ArrayList<Integer> orderList= new ArrayList<>();
	
	// package level
	OrderLine() {
	}
	
	public void addOrder(int num) {
		orderList.add(num);
	}

	public List<Integer> getOrderList() {
		return orderList;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return orderList.toString();
	}
	
}
