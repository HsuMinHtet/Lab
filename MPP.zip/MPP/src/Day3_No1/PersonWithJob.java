package Day3_No1;

public class PersonWithJob {
	
	private Person person;
	private double salary;
	
	public String getName() {
		return person.getName();
	}
	public double getSalary() {
		return salary;
	}
	PersonWithJob(String n, double s) {
		person = new Person(n);
		salary = s;
	}
	
	
	@Override
	public boolean equals(Object aPersonWithJob) {
		if(aPersonWithJob == null) return false; 
		if(!(aPersonWithJob instanceof PersonWithJob)) return false;//obj
		PersonWithJob p = (PersonWithJob)aPersonWithJob;
		boolean isEqual = this.getName().equals(p.getName()) &&
				this.getSalary()==p.getSalary();
		return isEqual;
	}
	
	
	public static void main(String[] args) {
		PersonWithJob pJob = new PersonWithJob("Joe", 30000);
		Person person = new Person("Joe");
		//if inheritance, it will false (child will not same with parent)
		//if association, it will true with only (p1.equals(p1)), otherwise, false
		System.out.println("p1.equals(p2)? " + pJob.equals(person));
		
		//if inheritance, it will true (parent will same with child)
		//if association, it will true with only (p2.equals(p2))otherwise, false
		System.out.println("p2.equals(p1)? " + person.equals(pJob));
	}


}
