package test.Day2.Practice;

public class Main {

	public static void main(String[] args) {
		// Create some items
		Item item1 = new Item("Item 1");
		Item item2 = new Item("Item 2");
		Item item3 = new Item("Item 3");

		// Create customers
		Customer customer1 = new Customer("Customer 1");
		Customer customer2 = new Customer("Customer 2");

		customer1.getCart().newShoppingCart(customer1);
		customer2.getCart().newShoppingCart(customer2);
		
		// Add items to their shopping carts
		customer1.getCart().addItem(item1);
		customer1.getCart().addItem(item2);

		customer2.getCart().addItem(item2);
		customer2.getCart().addItem(item3);

		// Display the items in each customer's cart
		System.out.println("Items in Customer 1's Cart:");
		for (Item item : customer1.getCart().getItems()) {
			System.out.println(item.getName());
		}

		System.out.println("\nItems in Customer 2's Cart:");
		for (Item item : customer2.getCart().getItems()) {
			System.out.println(item.getName());
		}
	}

}
