package final_Day2_Prob5;

import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

import final_Day2_prob3.myBiFunction;

public class ForEachExample {
	public static final List<String> list = Arrays.asList("Hello there", "Goodbye", "Back soon", "Away", "On Vacation",
			"Everywhere you want to be");
	public static void main(String[] args) {
		

		// a. Use a lambda expression instead of directly defining a Consumer
		list.forEach(s -> System.out.println(s.toUpperCase()));

		// b. Use a method reference in place of your lambda expression in (a)
		// list.stream().map(s->s.toUpperCase()).forEach(System.out::print);
		Consumer<String> consumer = System.out::print;
		Function<String, String> upper = String::toUpperCase;
		// list.forEach(s-> consumer.accept(s.toUpperCase()));
		list.forEach(System.out::print);
		// list.sort(String::compareToIgnoreCase);
		Consumer<String> conn= new Consumer<String>() {

			@Override
			public void accept(String t) {
				// TODO Auto-generated method stub
				System.out.println(t.toUpperCase());
			}
		};
		list.forEach(conn);
	}

}