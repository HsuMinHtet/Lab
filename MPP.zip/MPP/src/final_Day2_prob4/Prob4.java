package final_Day2_prob4;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

import lesson9.labs.prob11b.TriFunction;

public class Prob4 {

	public static void main(String[] args) {
		List<String> words = List.of("apple", "banana", "chery", "date", "elderberry");
		Prob4 prob4 = new Prob4();
		int result = prob4.countWords(words, 'c', 'd', 5);

		System.out.println("Number of words meeting the criteria(words that have length equal to len, that\n"
				+ "contain the character c, and that do not contain the character d): " + result);

	}

	final TriFunction<List<String>, String, String, List<String>> MyTri= (list,c,d)-> 
	list.stream().filter(s->s.contains(c)).filter(s-> !s.contains(d)).collect(Collectors.toList());
	
	final BiFunction<List<String>,Integer,Long> MyBi=(list,len)->
	list.stream().filter(s->s.length()==len).count();
	
	public int countWords(List<String> words, char c, char d, int len) {
		String cc= ""+c;
		String dd= ""+d;
		Long count =MyBi.apply(MyTri.apply(words, cc, dd), len);
		return count.intValue();
		/*
		return (int) words.stream()
				.filter(word -> word.length() == len)
				.filter(word -> word.indexOf(c) > -1)
				.filter(word -> word.indexOf(d) == -1)
				.count();*/
	}
}
