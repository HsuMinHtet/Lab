package standardExamPractice_1;

public interface EmployeeData {
	public double getSalary();
}
