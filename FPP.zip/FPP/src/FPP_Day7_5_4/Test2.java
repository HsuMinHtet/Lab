package FPP_Day7_5_4;

import java.util.ArrayList;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {

		List<Polygon> objects = new ArrayList<Polygon>();
		objects.add(new Square(3));
		objects.add(new Triangle(4, 5, 6));
		objects.add(new Rectangle(3, 4));

		String s = "For this ";

		for (int i = 0; i < objects.size(); i++) {
			if (objects.get(i).getClass() == Square.class) {
				s += "Square \n Number of sides = " + objects.get(i).getNumberOfSides();
			}
			if (objects.get(i).getClass() == Triangle.class) {
				s += "Triangle \n Number of sides = " + objects.get(i).getNumberOfSides();
			}
			if (objects.get(i).getClass() == Rectangle.class) {
				s += "Rectangle \n Number of sides = " + objects.get(i).getNumberOfSides();
			}
			System.out.printf(s + " \n Perimeter = %.1f\n", objects.get(i).computePerimeter());
			s = "\nFor this ";
		}

	}

}