package FPP_Day7_5_4;
abstract public class ClosedCurve {
	abstract double computeArea();

}
