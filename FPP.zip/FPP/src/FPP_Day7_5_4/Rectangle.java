package FPP_Day7_5_4;

public class Rectangle extends ClosedCurve implements Polygon{
	private double widht;
	private double height;
	
	public Rectangle(double widht, double height) {
		this.widht = widht;
		this.height = height;
	}
	
	double computeArea() {
		return widht * height;
	}

	@Override
	public int getNumberOfSides() {
		return 4;
	}

	@Override
	public double computePerimeter() {
		return (2*this.widht)+(2*this.height);
	}
}
