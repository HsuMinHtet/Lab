package FPP_Day7_5_4;

public interface Polygon {

	public int getNumberOfSides();

	public double computePerimeter();

}
