package FPP_Day4_2;

import java.util.Date;
import java.util.GregorianCalendar;

public class Employee {
	private Account savingsAcct;
	private Account checkingAcct;
	private Account retirementAcct;
	private String name;
	private GregorianCalendar	hireDate;

	// constructor
	public Employee(String name, int yearOfHire, int monthOfHire, int dayOfHire) {
		this.name = name;
		hireDate = new GregorianCalendar(yearOfHire, monthOfHire - 1, dayOfHire);
		//hireDate = cal.getTime();
	}

	public void createNewChecking(double startAmount) {
		this.checkingAcct = new Account(AccountType.CHECKING, startAmount);

	}

	public void createNewSavings(double startAmount) {
		this.savingsAcct = new Account(AccountType.SAVINGS, startAmount);

	}

	public void createNewRetirement(double startAmount) {
		this.retirementAcct = new Account(AccountType.RETIREMENT, startAmount);

	}

	public void deposit(AccountType acctType, double amt) {
		switch (acctType) {
		case CHECKING:
			this.checkingAcct.makeDeposit(amt);
			break;
		case SAVINGS:
			this.savingsAcct.makeDeposit(amt);
			break;
		case RETIREMENT:
			this.retirementAcct.makeDeposit(amt);
			break;
		}
	}

	public boolean withdraw(AccountType acctType, double amt) {
		switch (acctType) {
		case CHECKING:
			return this.checkingAcct.makeWithdrawal(amt);
			//break;
		case SAVINGS:
			return this.savingsAcct.makeWithdrawal(amt);
			//break;
		case RETIREMENT:
			return this.retirementAcct.makeWithdrawal(amt);
			//break;
		}
		return false;
	}

	public String getFormattedAcctInfo() {
		String letter = "\nACCOUNT INFO FOR " + this.name + " : \n\n";
		if (this.checkingAcct != null)
			letter += this.checkingAcct.toString() + "Hire Date: "+ this.hireDate.getTime()+"\n";
		if (this.savingsAcct != null)
			letter += this.savingsAcct.toString() + "\n";
		if (this.retirementAcct != null)
			letter += this.retirementAcct.toString() + "\n";
		return letter;
	}

}
