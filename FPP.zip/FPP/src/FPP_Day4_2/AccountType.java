package FPP_Day4_2;

enum AccountType {
	CHECKING, SAVINGS, RETIREMENT
};

