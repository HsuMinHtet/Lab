package FPP_Day4_2;

public class Account {
	private final static double DEFAULT_BALANCE = 0.0;
	private double balance;
	private AccountType accType;

	Account( AccountType accType, double balance) {
		
		this.accType = accType;
		this.balance = balance;
	}

	Account( AccountType accType) {
		this( accType, DEFAULT_BALANCE);
	}

	public String toString() {
		return "Account type : " + accType + "\nCurrent bal : " + balance;
	}

	public void makeDeposit(double deposit) {
		this.balance += deposit;
	}

	public boolean makeWithdrawal(double amount) {
		if (amount < balance) {
			this.balance = this.balance - amount;
			return true;
		} else
			return false;
	}

	public AccountType getAcctType() {
		return this.accType;
	}

	public double computeInterest() {
		double interest = 0.0;
		if (this.accType == AccountType.CHECKING) {
			interest = this.balance * 0.02;
		} else if (this.accType == AccountType.SAVINGS) {
			interest = this.balance * 0.04;
		} else if (this.accType == AccountType.RETIREMENT) {
			interest = this.balance * 0.05;
		}

		return interest;
	}
}
