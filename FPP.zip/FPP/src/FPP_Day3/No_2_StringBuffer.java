package FPP_Day3;

import java.util.Scanner;

public class No_2_StringBuffer {

	static void Lab_2_a() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Type some words : ");
		StringBuffer stBuffer = new StringBuffer(scanner.nextLine());
		stBuffer.append("bye");
		System.out.println(stBuffer);
		scanner.close();
	}

	static void Lab_2_b() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Type some words : ");
		StringBuffer stBuffer = new StringBuffer(scanner.nextLine());
		char char1;
		for (int i = 0; i < stBuffer.length(); i++) {
			char1 = stBuffer.charAt(i);
			if (char1 >= 97 && char1 <= 122) // lower{
				//char1 = (char) (char1 - 32);
				char1 = Character.toLowerCase(char1);
			else if(char1 >=65 && char1 <=90)
				char1 = (char) (char1 + 32);
			stBuffer.setCharAt(i, char1);
		}
		System.out.print(stBuffer);
		scanner.close();
	}

	public static void main(String[] args) {
		// Lab_2_a();
		Lab_2_b();
	}

}
