package FPP_Day3;

import java.util.Scanner;

public class No_3_ProgrammingAssignment2_12 {

	static int min(int[] arrayOfInts) {
		int min = Integer.MAX_VALUE;
		for (int i = 0; i < arrayOfInts.length; i++) {
			if (min > arrayOfInts[i])
				min = arrayOfInts[i];
		}
		return min;
	}

	static int avg(int[] arrayOfInts) {
		int avg = 0, sum = 0;
		for (int i = 0; i < arrayOfInts.length; i++) {
			sum += arrayOfInts[i];
		}
		return avg = sum / arrayOfInts.length;
	}

	static void upper_LowerCase() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Type some words : ");
		StringBuffer stBuffer = new StringBuffer(scanner.nextLine());
		char char1;
		for (int i = 0; i < stBuffer.length(); i++) {
			char1 = stBuffer.charAt(i);
			if (char1 >= 97 && char1 <= 122) // lower{
				char1 = (char) (char1 - 32);
			else if (char1 >= 65 && char1 <= 90)
				char1 = (char) (char1 + 32);
			stBuffer.setCharAt(i, char1);
		}
		System.out.print(stBuffer);
		scanner.close();
		System.out.println("\n\n");
	}

	static void dimensionalArray() {
		double[][] twoDimen = new double[3][6];
		double value = 10000;
		double rate = 10;
		int sum = 0;
		for (int j = 0; j < 6; j++) {
			for (int i = 0; i < 3; i++) {
				if (i == 0)
					twoDimen[i][j] = value;
				else {
					value += value * (rate / 100);
					twoDimen[i][j] = value;
				}
			}
			rate++;
			value = 10000;
		}
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 6; j++) {
				System.out.printf("%.2f", twoDimen[i][j]);
				System.out.print(" ");
			}
			System.out.println();
		}

		for (int i = 0; i < twoDimen.length; i++) {
			for (int j = 0; j < twoDimen[i].length; j++) {
				sum += twoDimen[i][j];
			}
			System.out.print("Avg of row " + i + " is " + sum / twoDimen.length+"\n");
		}

	}

	public static void main(String[] args) {
		System.out.println(min(new int[] { 2, -21, 3, 45, 0, 12, 18, 6, 3, 1, 0, -22 }));
		System.out.println(avg(new int[] { 2, -21, 3, 45, 0, 12, 18, 6, 3, 1, 0, -22 }));
		//upper_LowerCase();
		dimensionalArray();
	}

}
