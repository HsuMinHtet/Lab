package FPP_Day3;

public class No_4_Stars {

	static void a() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < i+1; j++) {
				if (i == j || j == 0)
					System.out.print("*");
				else {
					if (i == 5)
						System.out.print("*");
					else
						System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("--------------------------------");
	}

	static void b() {
		int row = 5;
		for (int i = 0; i <= row; i++) {
			for (int j = 0; j <= row; j++) {
				if (j == 5 || row - i == j)
					System.out.print("*");
				else {
					if (i == 5)
						System.out.print("*");
					else
						System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("--------------------------------");
	}

	static void c() {
		int row = 6;
		for (int i = 0; i <= row / 2; i++) {
			for (int j = 0; j <= row; j++) {
				if (((row / 2 - i) == j) || ((row / 2 + i) == j))
					System.out.print("*");
				else {
					if (i == row / 2)
						System.out.print("*");
					else
						System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("--------------------------------");
	}

	static void d() {
		int row = 6;
		for (int i = 0; i <= row; i++) {
			for (int j = 0; j <= 3; j++) {
				if (j == 0 || i == j)
					System.out.print("*");
				else {
					if (row - i == j)
						System.out.print("*");
					else
						System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("--------------------------------");
	}

	static void e() {
		int row = 6;
		for (int i = 0; i <= row; i++) {
			for (int j = 0; j <= row / 2; j++) {
				if (j == 3 || ((row / 2) - i == j))
					System.out.print("*");
				else {
					if (i - (row / 2) == j)
						System.out.print("*");
					else
						System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("--------------------------------");
	}

	static void f() {
		int row = 4;
		for (int i = 0; i <= row; i++) {
			for (int j = 0; j <= row; j++) {
				if (((row / 2 - i) == j) || ((row / 2 + i) == j))
					System.out.print("*");
				else {
					if (i - 2 == j || (i==3 && j==3))
						System.out.print("*");
					else
						System.out.print(" ");
				}

			}
			System.out.println();
		}
		System.out.println("--------------------------------");
	}

	public static void main(String[] args) {
		a();
		b();
		c();
		d();
		e();
		f();
	}

}
