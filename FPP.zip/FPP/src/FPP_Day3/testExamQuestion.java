package FPP_Day3;

public class testExamQuestion {

	public static void main(String[] args) {
		System.out.println(myCountOfCapitalLetters("HUUJello123"));
	}
	
	static int myCountOfCapitalLetters(String s) {
		int count =0;
		for(int i=0; i<s.length();i++) {
			char ch = s.charAt(i);
			if(ch>=65 && ch<=90) {
				count++;
			}
		}
		return count;
	}
	
}
