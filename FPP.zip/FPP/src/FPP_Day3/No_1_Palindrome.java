package FPP_Day3;

import java.util.Scanner;

public class No_1_Palindrome {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Type to check Palindrome: ");
		String st = scanner.nextLine();
		Character forward_ch, backward_ch;
		String answer = "";
		boolean isPalindrome = true;
		int j = st.length() - 1;
		for (int i = 0; i < st.length() / 2; i++) {
			j = j - i;
			forward_ch = st.charAt(i);		
			backward_ch = st.charAt(j);
			if (forward_ch.UPPERCASE_LETTER != backward_ch.UPPERCASE_LETTER) {
				isPalindrome = false;
				break;
			}	
		}
		System.out.print(isPalindrome);

		/*
		 * do {
		 * 
		 * answer = scanner.nextLine();
		 * 
		 * System.out.print("Do you want to continue? (Y:N) "); } while
		 * (answer.equals("Y"));
		 */
		scanner.close();
	}

}
