package FPP_Day4_1;

public class Account {
	private final static double DEFAULT_BALANCE = 0.0;
	private double balance;
	private Employee employee;
	private AccountType accType;

	Account(Employee emp, AccountType accType, double balance) {
		employee = emp;
		this.accType = accType;
		this.balance = balance;
	}

	Account(Employee emp, AccountType accType) {
		this(emp, accType, DEFAULT_BALANCE);
	}

	public String toString() {
		return "type = " + accType + ", balance = " + balance;
	}

	public void makeDeposit(double deposit) {
		this.balance += deposit;
	}

	public boolean makeWithdrawal(double amount) {
		if (amount < balance) {
			this.balance = this.balance - amount;
			return true;
		} else
			return false;
	}

	public AccountType getAcctType() {
		return this.accType;
	}

	public double computeInterest() {
		double interest = 0.0;
		if (this.accType == AccountType.CHECKING) {
			interest = this.balance * 0.02;
		} else if (this.accType == AccountType.SAVINGS) {
			interest = this.balance * 0.04;
		} else if (this.accType == AccountType.RETIREMENT) {
			interest = this.balance * 0.05;
		}

		return interest;
	}
}
