package FPP_Day4_1;

enum AccountType {
	CHECKING, SAVINGS, RETIREMENT
};

