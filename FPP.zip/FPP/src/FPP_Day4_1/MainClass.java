package FPP_Day4_1;

public class MainClass {

	public static void main(String[] args) {
		Employee emp = new Employee("Aung", 1000.00, 2020, 1, 1);
		Account account1 = new Account(emp, AccountType.CHECKING, 300.00);
		Account account2 = new Account(emp, AccountType.SAVINGS, 300.00);
		Account account3 = new Account(emp, AccountType.RETIREMENT, 300.00);
		System.out.println("Checking 	:"+account1.toString());
		System.out.println("Saving  		:"+account2.toString());
		System.out.println("Retirement 	:"+account3.toString());
	}

}
