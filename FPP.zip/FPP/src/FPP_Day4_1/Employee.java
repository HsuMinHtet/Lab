package FPP_Day4_1;

import java.util.GregorianCalendar;

public class Employee {
	private String name;
	private double salary;
	private GregorianCalendar hireDay;

	// constructor
	Employee(String aName, double aSalary, int aYear, int aMonth, int aDay) {
		name = aName;
		salary = aSalary;
		// GregorianCalendar cal = new GregorianCalendar(aYear, aMonth - 1, aDay);
	}

	// instance methods
	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	// needs to be improved!!
	public GregorianCalendar getHireDay() {
		return hireDay;
	}

	public void raiseSalary(double byPercent) {
		double raise = salary * byPercent / 100;
		salary += raise;
	}

	public double yearlyFederalTax() {
		double tax = 0.0;
		if (salary > 80000) {
			tax = salary * (28 / 100);
		} else if (salary <= 80000 && salary > 50000) {
			tax = salary * (24 / 100);
		} else if (salary <= 50000 && salary > 26000) {
			tax = salary * (20 / 100);
		} else {
			tax = salary;
		}
		return tax;
	}

}
