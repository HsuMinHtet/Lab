package oldQuestion;

public class practice2 {

	public static int findPower(int x, int y) {
		if (y == 0)
			return 1; // base
		else
			return x * findPower(x, y - 1);
	}

	public static boolean recursivePrime(int x, int i) {
		if (x <= 1)
			return false;
		else if (x == 2 || x == i) // base
			return true;

		if (x % i != 0)
			return recursivePrime(x, ++i);
		else
			return false;
	}
	//Hein
	public static boolean isPrime(int n,int i) {
		if(n<=1) return false;
        if(i>=n) return true;
        if(n % i==0) return false;
        
        return isPrime(n,i+1);
    }
	////////////
	public static void showPrime() {
		for (int x = 0; x <= 50; x++) {
			//if (recursivePrime(x, 2)) {
			if(isPrime(x, 2)) {
				System.out.println(x);
			}
		}
	}

	public static void writeatoz() {
		String s = "";
		for (int i = 97; i < 123; i++) {
			char ch = (char) i;
			s += " " + ch;
		}
		System.out.print(s);
	}


/////////////////
	static void PrimeRecurision1(int num) {

		if(num<=50) {

			if (isPrime1(num,2))

				System.out.println(num);

			PrimeRecurision1(num+1);

		}

	}

	

	public static boolean isPrime1(int n,int i) {

        if(i>=n) return true;

        if(n % i==0) return false;

        return isPrime1(n,i+1);

    }
	public static void main(String[] args) {
		// System.out.println(findPower(2, 3));
		showPrime();
		//PrimeRecurision1(50);
		// writeatoz();
	}

}
