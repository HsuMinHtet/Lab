package oldQuestion;

import java.util.ArrayList;

public class practice1 {

	static int HowMayDigits(String s) {
		int count = 0;
		for (int i = 0; i < s.length(); i++) {
			if (Character.isDigit(s.charAt(i)))
				count++;

		}
		return count;
	}

	static void changeTestScores(int[][] the_array) {

		for (int i = 0; i < the_array.length; i++) {
			for (int j = 0; j < the_array[i].length; j++) {
				if (the_array[i][j] >= 85) {
					the_array[i][j] += 4;
					// System.out.println(the_array[i][j]);
				} else
					the_array[i][j] += 7;
			}
		}
	}

	static boolean allEven(int[][] array1) {

		for (int i = 0; i < array1.length; i++) {
			for (int j = 0; j < array1[i].length; j++) {
				if (array1[i][j] % 2 != 0)
					return false;
			}
		}
		return true;
	}

	static boolean myEndsWith(String s1, String s2) {
		int j = s1.length() - 1;
		Character ch1, ch2;
		
		for (int i = s2.length() - 1; i >= 0; i--) {
			ch1 = s1.charAt(j);
			ch2 = s2.charAt(i);
			Character.toUpperCase(ch1);
			Character.toUpperCase(ch2);
			if (ch1 != ch2)
				return false;
			j--;
		}
		return true;
	}

	public static String returnStringWithShortestLength(ArrayList<String> arr) {
		String s="";
		int minIndex=0, minSize=Integer.MAX_VALUE;
		for(int i=0; i<arr.size();i++) {
			s=arr.get(i);
			if(minSize>s.length()) {
				minIndex=i;
				minSize=s.length();
			}
		}
		return arr.get(minIndex);
	}
	
	public static void writeNum() {
		int num1=3000,num2=0;
		for(int i=0; i<7 ;i++) {
			num2=num1;
			for(int j=0; j<i+1; j++) {
				System.out.print(" "+num2);
				num2+=100;
			}
			System.out.println();
			num1+=1000;
		}
	}
	
	public static void main(String[] args) {
		System.out.println(HowMayDigits("Hello 123 hay"));
		changeTestScores(new int[][] { { 1, 2, 86 }, { 4, 5, 6 }, { 7, 8, 9 } });
		System.out.println(allEven(new int[][] { { 2, 2, 86 }, { 4, 8, 6 }, { 2, 8, 10 } }));
		System.out.println(myEndsWith("Testing", "in"));
		ArrayList<String> a= new ArrayList<String>();
		a.add("cat");
		a.add("bird");
		a.add("ok");
		a.add("dog");
		System.out.println(returnStringWithShortestLength(a));
		writeNum();
	}

}
