package FPP_Day2;

import java.util.ArrayList;
import java.util.Arrays;

public class Prog6 {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		boolean isDuplicate = false;
		for (int i = 0; i < args.length; i++) {
			isDuplicate = false;
			if (list.size() == 0)
				list.add(args[i]);
			else {
				for (int j = 0; j < list.size(); j++) {
					if (list.get(j).equals(args[i])) {
						isDuplicate = true;
						break;
					}
				}
				if (isDuplicate == false)
					list.add(args[i]);
			}
		}
		System.out.println(list);

//		 HashSet<String> set = new HashSet<>();
//		 for (int i = 0; i < args.length; i++) {
//		 set.add(args[i]);
//		//System.out.println(args[i]);
//		}
//		System.out.println(set);
//		// *******//
	}
// another way to remove duplication
	public static void test(String[] args) {

		String str = Arrays.toString(args);
		str = str.replace("[", "");
		str = str.replace("]", "");
		String str2 = "";

		for (String s : str.split(",")) {
			if (!str2.contains(s.trim())) {
				str2 += s;
			}
		}
		System.out.println("[" + str2 + "]");
	}

}
