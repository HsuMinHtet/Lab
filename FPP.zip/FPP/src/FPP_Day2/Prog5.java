package FPP_Day2;

import java.util.Scanner;

public class Prog5 {

	public static void main(String[] args) {
		int count = 0;
		String st, st1 = "";
		char ch;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Type Hello : ");
		st = scanner.nextLine();
		for(int i=st.length()-1; i>=0; i--) {
			ch = st.charAt(i);
			st1 += ch ;

		}
		System.out.println(st1);
		System.out.println("----------");
		System.out.println("Type the sentence to count number of 'x':");
		st = scanner.nextLine();
		for (int i = 0; i < st.length(); i++) {
			ch = st.charAt(i);
			if (ch == 'x')
				count++;
		}
		System.out.println("Number 'x' is: " + count);

	}

}
