package FPP_Day2;

public class Prog2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float num1 = (float) 1.27, num2 = (float) 3.881, num3 = (float) 9.6;

		int sum = (int) (num1 + num2 + num3);
		int sum1 = (int) Math.round(num1 + num2 + num3);

		System.out.println("SUM : " + sum);
		System.out.println("SUM1 : " + sum1);

	}

}
