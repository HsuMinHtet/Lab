package FPP_Day2;

import java.util.Scanner;

public class HomeWork {

	public static void main(String[] args) {
		
		/** HW No.1 **
		System.out.println("Enter your age: ");
		Scanner scanner = new Scanner(System.in);
		int age = scanner.nextInt();
		String socialSecurityStatus= (age > 65)? "eligible" :"ineligible";
		System.out.println(socialSecurityStatus);
		*/
		
		/** HW No.2 **
		String s = "a friendly face";
		System.out.println(s.charAt(14));//f
		System.out.println(s.length());//15
		System.out.println(s.substring(2,9));//friendl
		System.out.println(s.substring(4));//iendly face
		*/
		
		/**
		//Area (A) = π * r^2
		Scanner scanner = new Scanner (System.in);
		System.out.println("Enter the radius of circle: ");
		double r=scanner.nextDouble();
		double a=Math.PI*Math.pow(r, 2);
		System.out.println("Area of circle: "+ a);
		
		// Diagonal (diag) = √(Length² + Width²)
		System.out.println("Enter the length of rectangle: ");
		double len=scanner.nextDouble();
		System.out.println("Enter the width of rectangle: ");
		double wid=scanner.nextDouble();
		double diag=  Math.sqrt(Math.pow(len, 2) + Math.pow(wid, 2));
		System.out.println("Diagonal of rectangle: "+ diag);
		**/
		int b;
		int a=(b=5);
		System.out.print("a :"+ a);
		
	}
}
