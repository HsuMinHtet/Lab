package FPP_Day5_3;

import java.util.*;
import java.util.Scanner;

public class Main {
	Employee[] emps = null;

	public static void main(String[] args) {
		Main2();
		new Main();

	}

	static void Main2() {
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee("Jim", 2010, 1, 3));
		list.add(new Employee("Kerry", 2013, 4, 12));
		list.add(new Employee("May", 2019, 9, 23));

		list.get(0).createAccount(new CheckingAccount(3000));
		list.get(0).createAccount(new SavingsAccount(2000));
		list.get(0).createAccount(new RetirementAccount(1000));

		list.get(1).createAccount(new CheckingAccount(2000));
		list.get(1).createAccount(new SavingsAccount(8000));

		list.get(2).createAccount(new CheckingAccount(2000));
		list.get(2).createAccount(new SavingsAccount(3000));
		list.get(2).createAccount(new RetirementAccount(400));
		for (Employee emp : list) {
			System.out.printf("\nTotal balance of an Employee : %.2f", emp.getBalance());
		}
		System.out.println();
	}

	Main() {
		Scanner sc = new Scanner(System.in);
		emps = new Employee[3];
		emps[0] = new Employee("Jim Daley", 2000, 9, 4);
		emps[1] = new Employee("Bob Reuben", 1998, 1, 5);
		emps[2] = new Employee("Susan Randolph", 1997, 2, 13);

		emps[0].createAccount(new CheckingAccount(3000));
		emps[0].createAccount(new SavingsAccount(2000));
		emps[0].createAccount(new RetirementAccount(1000));

		emps[1].createAccount(new CheckingAccount(2000));
		emps[1].createAccount(new SavingsAccount(8000));

		emps[2].createAccount(new CheckingAccount(2000));
		emps[2].createAccount(new SavingsAccount(3000));
		emps[2].createAccount(new RetirementAccount(400));

		System.out.print("\nA. See a report of all accounts.\n" + "B. Make a deposit." + "\nC. Make a withdrawal.\n"
				+ "Make a selection (A/B/C) : ");
		String feeback1 = sc.next().toUpperCase();
		switch (feeback1) {
		// report
		case "A":
			System.out.println(getFormattedAccountInfo() + "\n");
			break;
		// Deposit
		case "B":
			System.out.print(getNameList() + "\n");
			int person = sc.nextInt();
			System.out.print(getRelatedAccountType(person) + "\n");
			int account = sc.nextInt();
			System.out.print("Deposit amount: ");
			double amount = sc.nextDouble();
			depositToAccount(account, person, amount);
			break;
		// Withdraw
		case "C":
			System.out.print(getNameList() + "\n");
			int person1 = sc.nextInt();
			System.out.print(getRelatedAccountType(person1) + "\n");
			int account1 = sc.nextInt();
			System.out.print("Withdraw amount: ");
			double amount1 = sc.nextDouble();
			withdrawToAccount(account1, person1, amount1);
			break;
		}

		totalOfAllBalances();
		totalOfAllBalances1();

		sc.close();

	}

	String getFormattedAccountInfo() {
		String sentence = "";
		for (Employee e : this.emps) {
			sentence += e.getFormattedAcctInfo();
		}
		return sentence;
	}

	String getNameList() {
		String outPut = "\n";
		int i = 0;
		//
		for (Employee emp : emps) {
			outPut += i + ". " + emp.getName() + "\n";
			i++;
		}
		outPut += "Select an employee: (type a number) ";
		return outPut;
	}

	String getRelatedAccountType(int person) {
		String outPut1 = "\n";
		int j = 0;
		if (emps.length > person) {
			for (Account acc : emps[person].getAccount()) {
				outPut1 += j + ". " + acc.getAcctType() + "\n";
				j++;
			}
			outPut1 += "Select an account: (type a number) ";
		} else {
			System.out.print("This data is not exist.");
		}
		return outPut1;
	}

	void depositToAccount(int account, int person, double amount) {
		if (emps[person].getAccount().size() > account) {
			emps[person].getAccount().get(account).makeDeposit(amount);
			String st = "\n%.2f has been deposited in the\n" + emps[person].getAccount().get(account).getAcctType()
					+ " of " + emps[person].getName();
			System.out.printf(st, amount);
			// System.out.print(emps[person].getAccount().get(account).getBalance());
		} else {
			System.out.print("This data is not exist.");
		}
	}

	void withdrawToAccount(int account, int person, double amount) {
		if (emps[person].getAccount().size() > account) {
			emps[person].getAccount().get(account).makeWithdrawal(amount);
			String st = "\n%.2f has been withdraw in the\n" + emps[person].getAccount().get(account).getAcctType()
					+ " of " + emps[person].getName();
			System.out.printf(st, amount);
		} else {
			System.out.print("This data is not exist.");
		}
	}

	// poly
	void totalOfAllBalances() {
		double total = 0;
		for (Employee emp : emps) {
			for (Account acc : emp.getAccount()) {
				total += acc.getBalance();
			}
		}
		System.out.printf("\n\nTotal of All Balance in the bank : %.2f", total);
	}

	// ArrayList+poly
	void totalOfAllBalances1() {
		double total = 0;
		for (Employee emp : emps) {
			total += emp.getBalance();
		}
		System.out.printf("\n\nTotal of All Balance in the bank : %.2f", total);
	}
}