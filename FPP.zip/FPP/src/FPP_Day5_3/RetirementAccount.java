package FPP_Day5_3;

public class RetirementAccount extends Account {

	RetirementAccount(double balance) {
		super(balance);
	}

	public String getAcctType() {
		return "RETIREMENT";
	}

	public double withdrawal(double amount) {
		super.makeWithdrawal(amount + 1);
		return super.getBalance();
	}

	public double getBalance() {
		return super.getBalance();
	}

}
