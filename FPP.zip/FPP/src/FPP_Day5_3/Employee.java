package FPP_Day5_3;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

public class Employee {
	private String name;
	private Date hireDate;
	private ArrayList<Account> accounts;

	// constructor
	public Employee(String name, int yearOfHire, int monthOfHire, int dayOfHire) {
		this.name = name;
		GregorianCalendar cal = new GregorianCalendar(yearOfHire, monthOfHire - 1, dayOfHire);
		hireDate = cal.getTime();
		accounts = new ArrayList<Account>();
	}

	public String getName() {
		return name;
	}

	public void createAccount(Account acc) {
		this.accounts.add(acc);
	}

	public ArrayList<Account> getAccount() {
		return accounts;
	}

	public void deposit(String acctType, double amt) {
		for (Account acc : this.accounts) {
			if (acc.getAcctType().equalsIgnoreCase(acctType)) {
				acc.makeDeposit(amt);
			}
		}
	}

	public boolean withdraw(String acctType, double amt) {
		for (Account acc : this.accounts) {
			if (acc.getAcctType().equalsIgnoreCase(acctType)) {
				return acc.makeWithdrawal(amt);
			}
		}
		return false;
	}

	public String getFormattedAcctInfo() {
		String letter = "\n\nACCOUNT INFO FOR " + this.name + " : \n";
		for (Account acc : accounts) {
			letter += "\nAccount Type : " + acc.getAcctType() + "\nBalance : " + acc.getBalance();
		}
		return letter;
	}

	public double getBalance() {
		double total = 0.0;
		for (Account a : accounts) {
			total += a.getBalance();
		}
		return total;
	}

}
