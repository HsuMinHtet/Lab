package FPP_Day5_3;

public abstract class Account {
	private double balance;

	Account( double balance) {
		this.balance = balance;
	}
	

	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public String toString() {
		return "Current bal : " + balance;
	}

	public void makeDeposit(double deposit) {
		this.balance += deposit;
	}

	public boolean makeWithdrawal(double amount) {
		if (amount < balance) {
			this.balance = this.balance - amount;
			return true;
		} else {
			System.out.println("Your balance is insufficient.");
			return false;
		}		
	}
	
	 abstract String getAcctType();
	
}
