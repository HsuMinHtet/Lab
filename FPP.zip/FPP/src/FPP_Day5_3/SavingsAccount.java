package FPP_Day5_3;

public class SavingsAccount extends Account {

	SavingsAccount(double balance) {
		super(balance);
	}

	public String getAcctType() {
		return "SAVING";
	}

	public double saving() {
		super.makeWithdrawal(0.1);
		return super.getBalance();
	}

	public double getBalance() {
		return super.getBalance();
	}
}
