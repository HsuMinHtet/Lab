package FPP_Day5_3;

public class CheckingAccount extends Account {

	CheckingAccount(double balance) {
		super(balance);
	}

	public String getAcctType() {
		return "CHECKING";
	}
	
	public double  balanceRead() {
		super.makeWithdrawal(0.2);
		return super.getBalance();
	}
	public double  getBalance() {	
		return super.getBalance();
	}
}
