package FPP_Day_5_1;

import java.util.Date;
import java.util.GregorianCalendar;

public class DeptEmployee {
	private String name;
	private double salary;
	private Date hireDate;

	public DeptEmployee(String aName, double aSalary, int yearOfHire, int monthOfHire, int dayOfHire) {
		name = aName;
		salary = aSalary;
		GregorianCalendar cal = new GregorianCalendar(yearOfHire, monthOfHire - 1, dayOfHire);
		hireDate = cal.getTime();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public double computeSalary() {
		return this.salary;
	}
}
