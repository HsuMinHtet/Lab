package FPP_Day_5_1;

public class Secretary extends DeptEmployee {

	private double overtimeHours;

	public Secretary(String aName, double aSalary, int yearOfHire, int monthOfHire, int dayOfHire) {
		super(aName, aSalary, yearOfHire, monthOfHire, dayOfHire);
		overtimeHours = 0;
	}

	public double getOvertimeHours() {
		return overtimeHours;
	}

	public void setOvertimeHours(double overtimeHours) {
		this.overtimeHours = overtimeHours;
	}

	public double computeSalary() {
		double salarySecretary = super.computeSalary() + (12 * this.overtimeHours);
		return salarySecretary;
	}
}
