package FPP_Day_5_1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Professor pro1 = new Professor("Josphe", 9000, 2000, 7, 5);
		Professor pro2 = new Professor("Tala", 8000, 2000, 9, 4);
		Professor pro3 = new Professor("Assad", 7000, 2000, 5, 3);
		Secretary sec1 = new Secretary("Rose", 6000, 2000, 9, 6);
		Secretary sec2 = new Secretary("Jesmine", 6000, 2000, 12, 4);
		Administrator admin1 = new Administrator("Jame", 4000, 2000, 4, 4);
		Administrator admin2 = new Administrator("Morris", 4000, 2000, 7, 4);

		pro1.setNumberOfPublications(10);
		pro2.setNumberOfPublications(10);
		pro3.setNumberOfPublications(10);

		sec1.setOvertimeHours(200);
		sec2.setOvertimeHours(200);

		admin1.setWorkTime(8);
		admin2.setWorkTime(8);

		DeptEmployee[] department = new DeptEmployee[7];
		department[0] = pro1;
		department[1] = pro2;
		department[2] = pro3;
		department[3] = sec1;
		department[4] = sec2;
		department[5] = admin1;
		department[6] = admin2;

//		for phase I – console output all
		Scanner sc = new Scanner(System.in);
		boolean isExist = false;
		double totalSalary = 0.0;
		for (DeptEmployee dep : department) {
			totalSalary += dep.computeSalary();
		}
		System.out.printf("Total all salaries in the department : %.2f", + totalSalary);
		System.out.print("\nDo you wish to see the sum of all salaries in the department? (y/n) ");
		String answer = sc.next();
		if (answer.equalsIgnoreCase("y")) {
			for (DeptEmployee dep : department) {
				System.out.println("Name : " + dep.getName() + " ,Salary : " + dep.computeSalary());
			}
		} else {
			System.out.println("Thank you!");
		}

//		console output to search for the details of an employee
		System.out.print("Would like to search for the details of an employee? (y/n) ");
		String answer1 = sc.next();
		if (answer1.equalsIgnoreCase("Y")) {
			System.out.print("Enter an employee name: ");
			String eName = sc.next();
			for (DeptEmployee dep : department) {
				if (eName.equals(dep.getName())) {
					if (dep instanceof Professor) {
						Professor pro = (Professor) dep;
						System.out.println("Name : " + pro.getName() + "\nSalary : " + pro.computeSalary()
								+ "\nNumberOfPublications : " + pro.getNumberOfPublications() + "\nDate : "
								+ pro.getHireDate());
					}
					if (dep instanceof Secretary) {
						Secretary sec = (Secretary) dep;
						System.out.println("Name : " + sec.getName() + "\nSalary : " + sec.computeSalary()
								+ "\nOvertimeHours : " + sec.getOvertimeHours() + "\nDate : " + sec.getHireDate());
					}
					if (dep instanceof Administrator) {
						Administrator admin = (Administrator) dep;
						System.out.println("Name : " + admin.getName() + "\nSalary : " + admin.computeSalary()
								+ "\nWorkTime : " + admin.getWorkTime() + "\nDate : " + admin.getHireDate());
					}
					isExist = true;
				}
			}
			if (isExist == false) {
				System.out.println("This person is not in this department.");
			}
		}
		sc.close();
	}

}
