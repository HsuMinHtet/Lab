package FPP_Day_5_1;

public class Administrator extends DeptEmployee {

	private int workTime;

	public Administrator(String aName, double aSalary, int yearOfHire, int monthOfHire, int dayOfHire) {
		super(aName, aSalary, yearOfHire, monthOfHire, dayOfHire);
		workTime = 0;
	}

	public int getWorkTime() {
		return workTime;
	}

	public void setWorkTime(int workTime) {
		this.workTime = workTime;
	}

	public double computeSalary() {
		double salaryAdministrator = 20 * this.workTime;
		return salaryAdministrator;
	}
}
