package FPP_II_Day1;

public class MyLinkedList {

	private Node head;

	public MyLinkedList() {
		head = null;
	}

	public void insert(String x) {
		if (head == null) {
			head = new Node(x, null);
			return;
		}
		Node head1 = head;
		boolean continueInsert = true;
		while (continueInsert) {
			if (head1.next == null) {
				head1.next = new Node(x, null);
				continueInsert = false;
			} else
				head1 = head1.next;
		}
	}

	public String removeFrist() {
		Node temp;
		if (head == null)
			return null;
		else {
			temp=head;
			head=head.next;
			return temp.data;
		}
	}

	public String removeLast() {
		String num="";
		if (head == null)
			return null;
		if (head.next == null) {
			num=head.data;
			head=head.next;
			return num;
		}
		else {
			Node head1 = head;
			Node tail1 = head.next;
			
			while (tail1.next != null) {
				head1 = head1.next;
				tail1 = tail1.next;
			}
			if (tail1.next == null) {
				head1.next= null;
			}
			return tail1.data;
		}
	}

	public String find(int pos) {
		int index = 0;
		Node temp = head;
		if (head == null)
			return null;
		else {
			while (pos != index && temp.next != null) {
				temp = temp.next;
				index++;
			}
			if (pos == index) {
				return temp.data;
			}
			return null;
		}
	}

	public int size() {
		Node temp = head;
		int count = 1;
		if (head == null)
			return 0;
		else {
			while (temp.next != null) {
				temp = temp.next;
				count++;
			}
			return count;
		}
	}

	public void printMyList() {
		Node head1=head;
		if(head1==null)
			return;
		while(head1.next != null) {
			System.out.print(head1.data+",");
			head1=head1.next;
		}
		if(head1.next==null)
			System.out.print(head1.data);
	}
	
	public static void main(String[] args) {
		MyLinkedList myLinkList = new MyLinkedList();
		myLinkList.insert("test1");
		//myLinkList.insert("test2");
		//myLinkList.insert("test3");
		//myLinkList.insert("test4");
		// System.out.println("Size :" + myLinkList.size());
		/*
		for (int i = 0; i < 4; i++) {
			System.out.println("Size :" + myLinkList.size());
			System.out.println("No." + i +" :"+ myLinkList.removeLast());
		}
		*/
		//myLinkList.removeFrist();
		System.out.println(myLinkList.removeLast());
		myLinkList.printMyList();
	}

	class Node {
		String data;
		Node next;

		Node(String data) {
			this(data, null);
		}

		Node(String data, Node next) {
			this.data = data;
			this.next = next;
		}
	}

}
