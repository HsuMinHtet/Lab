package FPP_II_Day1;

import java.util.*;

public class LinkedListTesting {

	public static LinkedList<Integer> list;

	public static void main(String[] args) {
		list = new LinkedList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		printList();
		LinkedList<Integer> list2 = new LinkedList<Integer>();
		list2.add(1);
		list2.add(2);
		list2.add(3);
		list2.add(4);
		list2.add(5);
		concate(list, list2, 3);
		System.out.print(search(5, list2, 2) );
		delete(list2, 3, 2);
		System.out.println("Linked list print: "+list);
	}

	static void printList() {
		Iterator<Integer> it = list.iterator();
		System.out.println("List :");
		while (it.hasNext()) {
			System.out.print(it.next() + ",");
		}
	}

	static void concate(LinkedList<Integer> list1, LinkedList<Integer> list2, int position) {
		if ((list1 == null) || (list1.size() < position)) {
			System.out.println("Invalid to concate :");
			return;
		}
		Iterator<Integer> it = list2.iterator();
		while (it.hasNext()) {
			list1.add(position, it.next());
			position++;
		}
		System.out.println("\nConcate List :" + list1);
	}

	static int search(Integer num, LinkedList<Integer> list, int position) {
		if (list == null || position >= list.size()) {
			System.out.println("Invalid to concate :");
			return -1;
		}
		for (int i = position; i < list.size(); i++) {
			if(list.get(i)==num) {
				return i;
			}
		}
		return -1;
	}

	static void delete(LinkedList<Integer> list, int start, int span) {
		if (list == null || start > list.size() || (start + span) > list.size()) {
			System.out.println("Invalid to concate :");
			return;
		}
		for (int i = start; i < start + span; i++) {
			list.remove(start);
		}
		System.out.println("\nAfter remove List :" + list);
	}

}
