package FPP_II_Day1;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedList_Testing {
	static LinkedList<Character> A = new LinkedList<Character>();
	static LinkedList<Character> B = new LinkedList<Character>();
	static LinkedList<Character> C = new LinkedList<Character>();

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Sample Terminal Session");
		System.out.println(
				"\n1.	R for Read.\n2.	W for Write.\n3.	CL for clear linkedlist.\n4.	LEN for Lenght of LinkedList.\n5.	E for equal two list.\n6.	C for Concatenate.\n7.	I for Insert\n8.	S for search\n9.	D for delete\n10.	SUB for substring");
		System.out.print("\nenter command_>");
		String s = sc.next().toUpperCase();
		while (!s.equals("Q")) {
			switch (s) {
			case "R":
				Readstring();
				break;
			case "W":
				Write();
				break;
			case "C":
				chooseToConcat();
				break;
			case "E":
				chooseToEqual();
				break;
			case "CL":
				chooseToClearLen(0);
				break;
			case "LEN":
				chooseToClearLen(1);
				break;
			case "D":
				chooseToInsertSubstringDeleteSearch(0);
				break;
			case "S":
				chooseToInsertSubstringDeleteSearch(1);
				break;
			case "I":
				chooseToInsertSubstringDeleteSearch(2);
				break;
			case "SUB":
				chooseToInsertSubstringDeleteSearch(3);
				break;
			}
			System.out.print("\nenter command_>");
			s = sc.next().toUpperCase();
		}

		System.out.print("\nIndex for Search: " + search("BC", A, 0));
	}

	static void Readstring() {
		Scanner sc = new Scanner(System.in);
		System.out.print("\nenter string name_>");
		String s = sc.nextLine().toUpperCase();
		Scanner sc1 = new Scanner(System.in);
		System.out.print("\nenter text_>");
		String s1 = sc1.nextLine().toUpperCase();
		switch (s) {
		case "A":
			ReadStringToLinkedList(A, s1);
			break;
		case "B":
			ReadStringToLinkedList(B, s1);
			break;
		case "C":
			ReadStringToLinkedList(C, s1);
			break;
		}
	}

	static void ReadStringToLinkedList(LinkedList<Character> list, String s) {
		for (int i = 0; i < s.length(); i++) {
			list.add(s.charAt(i));
		}
	}

	static void Write() {
		Scanner sc = new Scanner(System.in);
		System.out.print("\nenter string name_>");
		String s = sc.nextLine().toUpperCase();
		switch (s) {
		case "A":
			Writestring(A);
			break;
		case "B":
			Writestring(B);
			break;
		case "C":
			Writestring(C);
			break;
		}
	}

	static void Writestring(LinkedList<Character> list) {
		String s = "";
		Iterator<Character> it = list.iterator();
		while (it.hasNext()) {
			s += it.next();
		}
		System.out.println(s);

	}

	static void chooseToClearLen(int num) {
		Scanner sc = new Scanner(System.in);
		System.out.print("\nenter string name _>");
		String s = sc.nextLine().toUpperCase();
		if (num == 0) {
			switch (s) {
			case "A":
				Clear(A);
				break;
			case "B":
				Clear(B);
				break;
			case "C":
				Clear(C);
				break;
			}
		} else {
			switch (s) {
			case "A":
				System.out.println("Lenght of list: " + Len(A));
				break;
			case "B":
				System.out.println("Lenght of list: " + Len(B));
				break;
			case "C":
				System.out.println("Lenght of list: " + Len(C));
				break;
			}
		}

	}

	static void Clear(LinkedList<Character> list) {
		if(list==null)
			return;
		Iterator it= list.iterator();
		while(it.hasNext()) {
			it.next();
			it.remove();
		}
	}

	static int Len(LinkedList<Character> list) {
		int lenght = 0;
		Iterator<Character> it = list.iterator();
		while (it.hasNext()) {
			lenght++;
			it.next();
		}
		return lenght;
	}

	static void chooseToEqual() {
		Scanner sc = new Scanner(System.in);
		System.out.print("\nenter string name 1_>");
		String s = sc.nextLine().toUpperCase();
		System.out.print("\nenter string name 2_>");
		String s1 = sc.nextLine().toUpperCase();
		switch (s) {
		case "A":
			if (s1.equals("B"))
				Equal(A, B);
			else if (s1.equals("C"))
				Equal(A, C);
			else if (s1.equals("A"))
				Equal(A, A);
			break;
		case "B":
			if (s1.equals("A"))
				Equal(B, A);
			else if (s1.equals("C"))
				Equal(B, C);
			else if (s1.equals("B"))
				Equal(B, B);
			break;
		case "C":
			if (s1.equals("A"))
				Equal(C, A);
			else if (s1.equals("B"))
				Equal(C, B);
			else if (s1.equals("C"))
				Equal(C, C);
			break;
		}
	}

	static void Equal(LinkedList<Character> list1, LinkedList<Character> list2) {
		
		if (list1 == null || list2 == null) {
			System.out.println("List are Null.");
			return;
		}

		if (Len(list1) != Len(list2)) {
			System.out.println("Size of list are different.");
			return;
		}
		Iterator<Character> it1 = list1.iterator();
		Iterator<Character> it2 = list2.iterator();
		while (it1.hasNext() && it2.hasNext()) {
			if (!(it1.next().equals(it2.next()))) {
				System.out.println("List are not equal.");
				return;
			}
		}
		System.out.println("List are equal.");
	}

	static void chooseToConcat() {
		Scanner sc = new Scanner(System.in);
		System.out.print("\nenter target>");
		String s = sc.nextLine().toUpperCase();
		System.out.print("\nenter string name_>");
		String s1 = sc.nextLine().toUpperCase();
		switch (s) {
		case "A":
			if (s1.equals("B"))
				Concatenate(A, B);
			else if (s1.equals("C"))
				Concatenate(A, B);
			else if (s1.equals("A"))
				Concatenate(A, A);
			break;
		case "B":
			if (s1.equals("A"))
				Concatenate(B, A);
			else if (s1.equals("C"))
				Concatenate(B, C);
			else if (s1.equals("B"))
				Concatenate(B, B);
			break;
		case "C":
			if (s1.equals("A"))
				Concatenate(C, A);
			else if (s1.equals("B"))
				Concatenate(C, B);
			else if (s1.equals("C"))
				Concatenate(C, C);
			break;
		}
	}

	static void Concatenate(LinkedList<Character> list1, LinkedList<Character> list2) {
		Iterator<Character> it = list2.iterator();
		if (list1 != null || list2 != null) {
			while (it.hasNext()) {
				list1.add(it.next());
			}
			// System.out.println("Concetenate :" + list1.toString());
		}

	}

	static void Insert(LinkedList<Character> list1, LinkedList<Character> list2, int position) {
		Iterator<Character> it = list2.iterator();
		if (position > list1.size())
			System.out.println("Invalid position.");
		else {
			while (it.hasNext()) {
				list1.add(position, it.next());
				position++;
			}
			System.out.println("Insert :" + list1.toString());
		}
	}

	static int Search(String s, LinkedList<Character> list, int position) {
		int i = 0;
		String target = "";
		Iterator<Character> it = list.iterator();
		if (s.length() < 0 || position < 0 || position > list.size())
			return -1;
		if (s.length() > (list.size() - position))
			return -1;
		while (it.hasNext()) {
			target += it.next();
		}
		return target.indexOf(s, position);
	}

	static void Delete(LinkedList<Character> list, int start, int span) {
		if (list.size() <= start || list.size() < start + span)
			System.out.print("Target position is wrong.");
		else {
			for (int i = start; i < start + span; i++) {
				list.remove(start);
			}
			System.out.println("REMOVE" + list.toString());
		}
	}

	static void chooseToInsertSubstringDeleteSearch(int num) {
		Scanner sc = new Scanner(System.in);
		System.out.print("\nenter target string_>");
		String s = sc.nextLine().toUpperCase();

		if (num == 0) {// delete
			System.out.print("\nenter start position_>");
			int start1 = sc.nextInt();
			System.out.print("\nenter span(count)_>");
			int count1 = sc.nextInt();
			switch (s) {
			case "A":
				Delete(A, start1, count1);
				break;
			case "B":
				Delete(B, start1, count1);
				break;
			case "C":
				Delete(C, start1, count1);
				break;
			}
		} else if (num == 1) {// Search
			System.out.print("\nenter String to search_>");
			String search = sc.nextLine();
			System.out.print("\nenter start position_>");
			int start2 = sc.nextInt();
			switch (s) {
			case "A":
				System.out.print("FOUND IN: " + Search(search, A, start2));
				break;
			case "B":
				System.out.print("FOUND IN: " + Search(search, B, start2));
				break;
			case "C":
				System.out.print("FOUND IN: " + Search(search, C, start2));
				break;
			}
		} else if (num == 2) {
			// Insert
			System.out.print("\nenter string name_>");
			String s1 = sc.nextLine().toUpperCase();
			System.out.print("\nenter start position_>");
			int start3 = sc.nextInt();
			switch (s) {
			case "A":
				if (s1.equals("B"))
					Insert(A, B, start3);
				else if (s1.equals("C"))
					Insert(A, C, start3);
				else if (s1.equals("A"))
					Insert(A, A, start3);
				break;
			case "B":
				if (s1.equals("B"))
					Insert(B, B, start3);
				else if (s1.equals("C"))
					Insert(B, C, start3);
				else if (s1.equals("A"))
					Insert(B, A, start3);
				break;
			case "C":
				if (s1.equals("C"))
					Insert(C, B, start3);
				else if (s1.equals("C"))
					Insert(C, C, start3);
				else if (s1.equals("A"))
					Insert(C, A, start3);
				break;
			}
		} else {
			// SubString
			System.out.print("\nenter string name_>");
			String s2 = sc.nextLine().toUpperCase();
			System.out.print("\nenter start position_>");
			int start3 = sc.nextInt();
			System.out.print("\nenter span(count)_>");
			int count2 = sc.nextInt();
			switch (s) {
			case "A":
				if (s2.equals("B"))
					Substring(A, B, start3, count2);
				else if (s2.equals("C"))
					Substring(A, C, start3, count2);
				else if (s2.equals("A"))
					Substring(A, A, start3, count2);
				break;
			case "B":
				if (s2.equals("B"))
					Substring(B, B, start3, count2);
				else if (s2.equals("C"))
					Substring(B, C, start3, count2);
				else if (s2.equals("A"))
					Substring(B, A, start3, count2);
				break;
			case "C":
				if (s2.equals("C"))
					Substring(C, B, start3, count2);
				else if (s2.equals("C"))
					Substring(C, C, start3, count2);
				else if (s2.equals("A"))
					Substring(C, A, start3, count2);
				break;
			}
		}

	}

	static void Substring(LinkedList<Character> list1, LinkedList<Character> list2, int start, int span) {
		if (list2.size() <= start || list2.size() < start + span)
			System.out.print("Target position is wrong.");
		else {
			list1.clear();
			for (int i = start; i < start + span; i++) {
				list1.add(list2.get(i));
			}
			System.out.println("Substring" + list1.toString());
		}
	}

	public static int search(String searchStr, LinkedList<Character> target, int start) {

		int index = -1;

		if (start < 0 || start >= target.size()) {

			return -1;

		}

		int searchString = searchStr.length();

		if (searchString == 0 || searchString > target.size()) {

			return -1;

		}

		for (int i = start; i < target.size(); i++) {

			int j = 0;

			int k = i;

			while (j < searchString && k < target.size() && searchStr.charAt(j) == target.get(k)) {

				j++;

				k++;

			}

			if (j == searchString) {

				index = i;

			}

		}

		return index;

	}

}
