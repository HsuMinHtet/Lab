package standardExamPractice_2;

public abstract class Vehicle {
	public abstract int getMilesUsedToday();
}
