package standardExamPractice_2;

import java.util.List;

public class MilesCounter {
	public static List<Vehicle> convertArray(Object[] vehicleArray) {
		List<Vehicle> list = null;
		for (Object b : vehicleArray) {
			list.add((Vehicle) b);
		}
		return list;
	}

	public static int computeTotalMiles(List<Vehicle> vehicleList) {
		int totalSalary=0;
		for(Vehicle v: vehicleList) {
			totalSalary+=v.getMilesUsedToday();
		}
		return totalSalary;
	}
}
