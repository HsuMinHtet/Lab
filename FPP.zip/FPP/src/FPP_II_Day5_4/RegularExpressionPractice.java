package FPP_II_Day5_4;

import java.util.Scanner;

public class RegularExpressionPractice {

	//private static final String VALID_IDENTIFIER_PATTERN ="^([a-z 0-9\\_\\-\\.]*)@([a-z 0-9\\_\\-\\.]*)\\.([a-z]{3})$";
	private static final String VALID_IDENTIFIER_PATTERN = "([a-z 0-9._]*)@([a-z0-9._]*)[a-z]{3}";
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter email");
		String s = sc.nextLine();
		if(s.matches(VALID_IDENTIFIER_PATTERN))
			System.out.println("Valid");
		else
			System.out.println("Invalid");

	}

}
