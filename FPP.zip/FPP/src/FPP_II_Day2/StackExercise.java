package FPP_II_Day2;

import java.util.*;

public class StackExercise {

	public static void main(String[] args) {
		LinkedList<Integer> stack1 = new LinkedList<Integer>();
		for (int i = 0; i < 5; i++) {
			stack1.push(i);
		}
		LinkedList<Integer> stack2 = new LinkedList<Integer>();
		for (int i = 5; i >= 0; i--) {
			stack2.push(i);
		}
		printStack(stack1);
		System.out.println("\nIs equal:"+equal(stack1, stack2));

	}

	static void printStack(LinkedList<Integer> stack) {
		int len = stack.size() - 1;
		while (!stack.isEmpty()) {
			if (len == 0)
				System.out.print("and " + stack.pop());
			else
				System.out.print(stack.pop() + " ,");
			len--;
		}
	}

	static int equal(LinkedList<Integer> stack1, LinkedList<Integer> stack2) {
		if(stack1==null || stack2==null)
			return 0;
		if(stack1.size()!=stack2.size())
			return 0;
		while(stack1.isEmpty()==false && stack2.isEmpty()) {
			if(!(stack1.peek().equals(stack2.peek())))
					return 0;
		}
		return 1;
	}

}
