package FPP_II_Day2;

import java.util.LinkedList;
import java.util.Scanner;

public class MyStack {

	static LinkedList<Integer> stack1 = new LinkedList<Integer>();
	static LinkedList<Character> stack2 = new LinkedList<Character>();

	public static void main(String[] args) {
		/*
		 * System.out.println("Enter some integers for me to reverse :");
		 * System.out.println("Type -1 t0 stop"); Scanner sc = new Scanner(System.in);
		 * int num = sc.nextInt(); while (num != -1) { stack1.push(num); sc = new
		 * Scanner(System.in); num = sc.nextInt(); }
		 */
		// System.out.println("The integers reversed are : " + stack1.toString());
		// outPut();
		// delimiterMatching("(-1a+b[(x+y)]+10)");
		System.out.println("Match or not: " + delimiterMatching_StackQueue("(-1a+b[(x+y)]+10)]"));
	}

	static void outPut() {
		String s = "";
		int length = stack1.size() - 1;
		while (!stack1.isEmpty()) {
			if (length == 0) {
				s += "and " + String.valueOf(stack1.pop());
			} else {
				s += String.valueOf(stack1.pop()) + ",";
			}
			length--;
		}
		System.out.println("The integers reversed are :  " + s);
	}

	static void delimiterMatching(String s) {
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);

			if (ch == '(' || ch == '{' || ch == '[') {
				stack2.push(ch);
			} else if (ch == ')' || ch == '}' || ch == ']') {
				if (stack2.isEmpty()) {
					System.out.println("Delimiter is Missing.");
					break;
				}
				char ch1 = stack2.peek();
				if ((ch1 == '(' && ch == ')') || (ch1 == '[' && ch == ']') || (ch1 == '{' && ch == '}')) {
					stack2.pop();
				} else {
					System.out.println("Delimiter is Missing.");
					break;
				}

			}
		}
		System.out.println("It is match.");
	}

	static int delimiterMatching_StackQueue(String s) {
		LinkedList<Character> myStack = new LinkedList<Character>();
		LinkedList<Character> myQueue = new LinkedList<Character>();
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (ch == '(' || ch == '<' || ch == '[' || ch == '{')
				myStack.push(ch);
			else if (ch == ')' || ch == '>' || ch == '}' || ch == ']')
				myQueue.add(ch);
		}
		if (myQueue.size() != myStack.size())
			return 0;
		int size=myStack.size();
		int count=0;
		for( int i=0; i<size;i++) {
			char ch1=myStack.pop();
			char ch= myQueue.remove();
			if((ch1 == '(' && ch == ')') || (ch1 == '[' && ch == ']') || (ch1 == '{' && ch == '}')) 
				count++;
			else
				return 0;
		}
		if(count==size)
			return 1;
		else 
			return 0;
	}
}
