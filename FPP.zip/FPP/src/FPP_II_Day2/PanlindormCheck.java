package FPP_II_Day2;

import java.util.LinkedList;
import java.util.Scanner;

public class PanlindormCheck {

	public static void main(String[] args) {
		System.out.println(isPanlindorm());

	}

	static boolean isPanlindorm() {
		LinkedList<Character> myStack = new LinkedList<Character>();
		LinkedList<Character> myQueue = new LinkedList<Character>();
		System.out.println("Enter a word to check Palindrom");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine().toLowerCase();
		for (int i = 0; i < s.length() ; i++) {
			if (i < s.length() / 2) {
				myStack.push(s.charAt(i));
			} else if (i > s.length() / 2 && s.length() % 2 != 0) {// size odd
				myQueue.add(s.charAt(i));
			} else if (i >= s.length() / 2 && s.length() % 2 == 0) {// size even
				myQueue.add(s.charAt(i));
			}
		}
		for(int i=0; i<s.length()/2 ; i++) {
			if(myStack.pop()!=myQueue.poll())
				return false;
		}
		return true;
	}

}
