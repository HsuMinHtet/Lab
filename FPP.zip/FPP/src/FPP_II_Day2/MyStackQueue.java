package FPP_II_Day2;

import java.util.LinkedList;
import java.util.Scanner;

/*
 * Questions :  1)  What is a deque?
 * Answer : 1)	Dequeue :  double-ended queue
 * allows elements to be inserted and removed from both ends (front and rear) of the queue
 */
public class MyStackQueue {
	static LinkedList<Integer> stack1 = new LinkedList<Integer>();
	static LinkedList<Integer> queue1 = new LinkedList<Integer>();

	public static void main(String[] args) {
	
		System.out.println("Enter some integers for stack :");
		System.out.println("Type -1 t0 stop");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();

		while (num != -1) {
			stack1.push(num);
			sc = new Scanner(System.in);
			num = sc.nextInt();
		}
		// System.out.println("(StoQ) Stack : " + stack1.toString());
		stackToQueue();
		queueToStack();
		stackToStack();
	}

	static void stackToQueue() {
		while (!stack1.isEmpty()) {
			queue1.add(stack1.pop());
		}
		System.out.println("(StoQ) Queue : " + queue1.toString());
	}

	static void queueToStack() {
		while (!queue1.isEmpty()) {
			stack1.push(queue1.remove());
		}
		System.out.println("(QtoS) Queue : " + stack1.toString());
	}

	// to correct
	static void stackToStack() {
		LinkedList<Integer> stack2 = new LinkedList<Integer>();
		LinkedList<Integer> queueTemp = new LinkedList<Integer>();
		if(stack1==null)
			return;
		int index= stack1.size()-1;
		System.out.println("(StoS) Stack copy 1: " + stack1);
		while(!stack1.isEmpty()) {
			queueTemp.add(stack1.pop());
		}
		while(index>=0) {
			stack2.push(queueTemp.get(index));
			index--;
		}
		System.out.println("(StoS) Stack copy 2: " + stack2);
	}

}
