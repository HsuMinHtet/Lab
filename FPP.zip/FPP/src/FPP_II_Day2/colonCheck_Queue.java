package FPP_II_Day2;

import java.util.*;

public class colonCheck_Queue {

	public static void main(String[] args) {
		System.out.println(
				"N      No colon on the line." + "\nL      The left part (before the colon) is longer than the right."
						+ "\nR      The right part (after the colon) is longer than the left."
						+ "\nD      The left and right parts have the same length but are different."
						+ "\nS      The left and right parts are exactly the same.");
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		String str = "";
		String contineStr = "Y";
		while (!contineStr.equals("N")) {
			System.out.println("Enter one sentence line with ':' ");
			str = sc1.nextLine();
			findSeperator(str);
			System.out.println(checkStringQueue(str));

			// check continue
			System.out.println("Do you want to continue? (Y/N) :");
			contineStr = sc.next().toUpperCase();
		}

	}

	// put first string part to Queue and while reading right part check with queue
	static int checkStringQueue(String str) {
		LinkedList<Character> queue = new LinkedList<Character>();
		int index = str.indexOf(':');
		if (index < 0)
			return 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (ch != ':' && index > i) {
				queue.add(ch);
			} else if (ch != ':' && index < i) {
				if (queue.isEmpty() == false && queue.remove() != ch)
					return 0;
			}
		}
		return 1;
	}

	static void findSeperator(String str) {
		String s1 = "";
		String s2 = "";
		LinkedList<Character> stack = new LinkedList<Character>();
		LinkedList<Character> queue = new LinkedList<Character>();
		int index = str.indexOf(':');
		if (index > 0) {
			for (int i = 0; i < str.length(); i++) {
				char ch = str.charAt(i);
				if (ch != ':' && index > i) {
					// s1 += ch;
					stack.push(ch);
				} else if (ch != ':' && index < i) {
					// s2 += ch;
					queue.add(ch);
				}
			}
			// System.out.println("Index: " +index);
			checkString(stack, queue);
		} else {
			System.out.println("Output :" + 'N');
		}
	}

	static void checkString(LinkedList<Character> stack, LinkedList<Character> queue) {
		if (stack == null || queue == null)
			return;
		int length = stack.size() - 1;
		if (stack.size() > queue.size()) {
			System.out.println("Output :" + 'L');
		} else if (stack.size() < queue.size()) {
			System.out.println("Output :" + 'R');
		} else {
			for (int i = 0; i <= length; i++) {
				if(stack.pop()!=queue.remove()) {
					System.out.println("Output :" + 'D');
					return;
				}
			}
			System.out.println("Output :" + 'S');
		}
	}
}
