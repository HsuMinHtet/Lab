package standardExamFinal1;

public class MyQueue {

	private int[] arr = new int[10];
	private int front = -1;
	private int rear = 0;

	public boolean isEmpty() {
		if (front == -1 || front >= rear)
			return true;
		else
			return false;
	}

	public void enqueue(int num) {
		if (front == -1)
			front++;
		if (rear < arr.length) 
			arr[rear++] = num;

		else {
			int[] tempArr = new int[rear+1];
			for (int i = 0; i < arr.length; i++) {
				tempArr[i] = arr[i];
			}
			tempArr[rear++] = num;
			arr=tempArr;
		}
	}

	public int dequeue() throws QueueException {
		if (isEmpty())
			throw new QueueException("Queue Empty");
		return arr[front++];
	}

	public int peek() throws QueueException {
		if (isEmpty())
			throw new QueueException("Queue Empty");
		return arr[front];
	}

	public int size() {
		return rear - front;
	}

	public static void main(String[] args) throws QueueException {
		MyQueue q = new MyQueue();

		 System.out.println("The value of 15 is : " + q.peek());

		for (int i = 0; i < 15; i++) {
			q.enqueue(i);
		}
		System.out.println("Size :" + q.size());
		for (int i = 0; i < 10; i++) {
			;
			System.out.println(q.dequeue());
		}
		System.out.println("The peek value(front) of queue is : " + q.peek());

	}

}
