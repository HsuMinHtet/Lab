package standardExamFinal1;

public class Main {

	public static void main(String[] args) throws QueueException {
		ArrayQueueImpl q = new ArrayQueueImpl();

		//System.out.println("The value of 15 is : " + q.peek());

		for (int i = 0; i < 15; i++) {
			q.enqueue(i);
		}
		System.out.println("Size :" + q.size());
		for (int i = 0; i < 10; i++) {
			;
			System.out.println(q.dequeue());
		}
		System.out.println("The peek value(front) of queue is : " + q.peek());

	}

}
