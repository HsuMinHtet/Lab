package standardExamFinal1;

public class ArrayQueueImpl {

	private int[] arr = new int[10];
	private int front = -1;
	private int rear = 0;

	public int peek() throws QueueException {
		if (isEmpty())
			throw new QueueException("Queue is Empty");
		return arr[front + 1];
	}

	public void enqueue(int obj) {
		if (rear < arr.length) {
			arr[rear] = obj;
			rear++;
		} else {
			int[] temp = new int[arr.length + 1];
			// System.out.println("Rear :"+ rear);
			for (int i = 0; i < arr.length; i++) {
				temp[i] = arr[i];
			}
			temp[rear] = obj;
			arr = temp;
			rear++;
		}
	}

	public int dequeue() throws QueueException {
		int num = 0;
		if (isEmpty())
			throw new QueueException("No Data in Queue");
		if (++front < rear) {
			num = arr[front];
		}
		return num;
	}

	public boolean isEmpty() {
		if (rear - front - 1 == 0)
			return true;
		else
			return false;
	}

	public int size() {
		return rear - front - 1;
	}

}
