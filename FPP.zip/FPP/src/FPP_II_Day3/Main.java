package FPP_II_Day3;

public class Main {

	public static void main(String[] args) {
		MyBST bst = new MyBST();
		bst.insert(15);
		bst.insert(12);
		bst.insert(9);
		bst.insert(56);
		bst.insert(1);
		bst.insert(16);
		bst.insert(19);
		bst.insert(22);
		bst.insert(3);
		bst.insert(100);
		bst.insert(2);
		//bst.insert(0);
		bst.insert(25);
		System.out.println("In-Order");
		bst.printTree_InOrder();
		System.out.println();
		System.out.println("\nPre-Order");
		bst.printTree_PreOrder();
		System.out.println();
		System.out.println("\nPost-Order");
		bst.printTree_PostOrder();
		System.out.println();

		System.out.println("\nCount of Node : " + bst.countnodes());
		System.out.println("Count of Leaf : " + bst.countleaf());

		System.out.println("\nIs All Even? : " + bst.allEven());
		System.out.println("Count of Even : " + bst.countHowManyAreAllEven());
		
		System.out.println("\nSearch no of elements greater than 9 : " + bst.searchNode(9));
		
		System.out.println("\nMax : " + bst.findMax());
		System.out.println("\nMin : " + bst.findMin());
		
		System.out.println("\nOnly Left child : " + bst.leftChildNodeCount());
		
		//System.out.println("Middle Node: "+ bst.findMiddle());
	}

}
