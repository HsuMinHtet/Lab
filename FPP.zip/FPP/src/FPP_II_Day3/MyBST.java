package FPP_II_Day3;

public class MyBST {
	/** The tree root. */
	private BinaryNode root;

	public MyBST() {
		root = null;
	}

	// Assume the data in the Node is an Integer.
	public void insert(Integer x) {
		if (root == null) {// start creating the head of node
			root = new BinaryNode(x, null, null);
			return; // not to continue the following line in void method
		}

		BinaryNode n = root;
		boolean continueInsert = true;

		while (continueInsert) {
			if (x.compareTo(n.element) < 0) {
				// space found on the left
				if (n.left == null) {
					n.left = new BinaryNode(x, null, null);
					continueInsert = false;
				}
				// keep looking for a place to insert (a null)
				else {
					n = n.left;
				}
			} else if (x.compareTo(n.element) > 0) {
				// space found on the right
				if (n.right == null) {
					n.right = new BinaryNode(x, null, null);
					continueInsert = false;
				}
				// keep looking for a place to insert (a null)
				else {
					n = n.right;
				}
			}
		}

	}

	public int searchNode(int x) {
		if (root == null) {
			return 0;
		} else
			return searchNode(x, root);
	}

	private int searchNode(int x, BinaryNode t) {
		int count = 0;
		if (t == null)
			return 0;
		else if (t.element == x)
			count++;
		return count + searchNode(x, t.left) + searchNode(x, t.right);

	}

	/**
	 * Prints the values in the nodes of the tree in sorted order.
	 */
	public void printTree_InOrder() {
		if (root == null)
			System.out.println("Empty tree");
		else
			printTree_InOrder(root);
	}

	private void printTree_InOrder(BinaryNode t) {
		if (t != null) {
			printTree_InOrder(t.left);
			System.out.print(t.element + ",");
			printTree_InOrder(t.right);
		} // An IN-ORDER Traversal
	}

	public void printTree_PreOrder() {
		if (root == null)
			System.out.println("Empty tree");
		else
			printTree_PreOrder(root);
	}

	private void printTree_PreOrder(BinaryNode t) {
		if (t != null) {
			System.out.print(t.element + ",");
			printTree_PreOrder(t.left);
			printTree_PreOrder(t.right);
		} // An PRE-ORDER Traversal
	}

	public void printTree_PostOrder() {
		if (root == null)
			System.out.println("Empty tree");
		else
			printTree_PostOrder(root);
	}

	private void printTree_PostOrder(BinaryNode t) {
		if (t != null) {
			printTree_PostOrder(t.left);
			printTree_PostOrder(t.right);
			System.out.print(t.element + ",");
		} // An POST-ORDER Traversal
	}

	public int countnodes() {
		if (root == null)
			return 0;
		else {
			return countnode(root);
		}
	}

	private int countnode(BinaryNode t) {
		if (t == null) {
			return 0;
		} else {
			return 1 + countnode(t.left) + countnode(t.right);
		} // node count
	}

	public int countleaf() {
		if (root == null)
			return 0;
		else {
			return countleaf(root);
		}
	}

	private int countleaf(BinaryNode t) {
		int count = 0;
		if (t == null) // eventuality
			return 0;
		else if (t.left == null && t.right == null) // base
			count++;
		return count + countleaf(t.left) + countleaf(t.right);
		// leaf count
	}

	public Integer leftChildNodeCount() {
		if (root == null)
			return 0;
		return leftChildNodeCount(root);
	}

	private Integer leftChildNodeCount(BinaryNode t) {
		int count = 0;
		if (t == null)
			return 0;
		if (t.left != null && t.right == null)
			count++;
		return count + leftChildNodeCount(t.left) + leftChildNodeCount(t.right);
	}
	
	public boolean allEven() {
		if (root == null)
			return false;
		else
			return allEven(root);
	}

	private boolean allEven(BinaryNode t) {
		boolean isEven = false;
		if (t == null)// eventuality
			return true;
		if (t.element % 2 == 0)
			isEven = true;

		return isEven && allEven(t.left) && allEven(t.right);
	}

	public int countHowManyAreAllEven() {
		if (root == null)
			return 0;
		else
			return countHowManyAreAllEven(root);
	}

	public int countHowManyAreAllEven(BinaryNode t) {
		int count = 0;
		if (t == null)// eventuality
			return 0;
		if (t.element % 2 == 0)// base
			count++;
		return count + countHowManyAreAllEven(t.left) + countHowManyAreAllEven(t.right);
	}

	public Integer findMax() {
		if (root == null)
			return 0;
		else
			return findMax(root);
	}

	private Integer findMax(BinaryNode t) {
		if (t == null)// eventuality
			return 0;
		while (t.right != null) {
			t = t.right;
		}
		return t.element;
	}

	public Integer findMin() {
		BinaryNode t = root;
		if (t == null)
			return 0;
		while (t.left != null) {
			t = t.left;
		}
		return t.element;
	}



	/*
	 * public Integer findMiddle() { if (root == null) return 0; else {
	 * 
	 * findMiddle(root);
	 * 
	 * //System.out.println("Middle test:" + list.toString()); } return null; }
	 * 
	 * public Integer findMiddle(BinaryNode t) { List<Integer> list = new
	 * ArrayList<Integer>(); while ((t.left != null && t.right != null)) { while
	 * (t.left != null) { list.add(t.element); t = t.left; } while (t.right != null)
	 * { list.add(t.element); t = t.right; } }
	 * 
	 * if (t.left == null && t.right == null) { System.out.println("Middle test:" +
	 * list.toString()); } return null; }
	 */
}