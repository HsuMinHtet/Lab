package FPP_II_Day3;

class BinaryNode {
	Integer element;// The data in the node
	BinaryNode left; // Left child
	BinaryNode right; // Right child
	// Constructors
	BinaryNode(Integer theElement) {
		this(theElement, null, null);
	}

	BinaryNode(Integer element, BinaryNode left, BinaryNode right) {
		this.element = element;
		this.left = left;
		this.right = right;
	}


}