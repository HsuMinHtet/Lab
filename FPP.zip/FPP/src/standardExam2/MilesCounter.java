package standardExam2;

import java.util.ArrayList;
import java.util.List;

public class MilesCounter {
	public static List<Vehicle> convertArray(Object[] vehicleArray) {
		Vehicle v;
		List<Vehicle> list = new ArrayList<Vehicle>();
		for (Object obj : vehicleArray) {
			v = (Vehicle) obj;
			list.add(v);
		}
		return list;
	}

	public static int computeTotalMiles(List<Vehicle> vehicleList) {
		int totalMiles = 0;
		for (int i = 0; i < vehicleList.size(); i++) {
			totalMiles += vehicleList.get(i).getMilesUsedToday();
		}
		return totalMiles;
	}
}
