package standardExam2;

public abstract class Vehicle {
	public abstract int getMilesUsedToday();
}
