package testing;

public class CallByValueCallByReference {

	public static void main(String[] args) {
		
		//pass by value (copy) Primitive data type
		int x=10;
		tripleValue(x);
		System.out.println("Value of x: "+ x);
		
		
		//pass by reference (copy) object
		Person person= new Person("Aclice");
		modifyName(person);
		System.out.println("Person name: "+ person.name);
		
	}
	 static void tripleValue(int x) {
		int value= 30;
	}
	 
	 static void modifyName(Person p) {
		 p.name="Bob";
	 }
}

class Person{
	String name;
	Person(String name){
		this.name=name;
	}
}
