package FPP_Day_10;

import java.util.Scanner;

public class AssertHelloWorld {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the age.");
		
		int x = sc.nextInt();
		 assert x>0 && x<140 : "Try later! Age should be between 1 and 140. Now you entered " + x;
		System.out.println("Thank you. We recroded your age. Age: "+ x);

	}
}
