package standardExam1;
import java.util.*;
public class Statistics {
	/** 
	 * Polymorphically computes and returns the sum
	 * of all the salaries of all the staff/teachers in the list.
	 */
	public static double computeSumOfSalaries(List<EmployeeData> aList) {
		double totalSalary=0.0;
		for(int i=0;i<aList.size();i++) {
			//System.out.println(aList.size());
			totalSalary+=aList.get(i).getSalary();
		}	
		return totalSalary;
		//implement
		//compute sum of all salaries of people in aList and return
	}
}
