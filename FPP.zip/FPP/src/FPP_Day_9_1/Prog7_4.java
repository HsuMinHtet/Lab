package FPP_Day_9_1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Prog7_4 extends JFrame {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setTitle("MyMenuFrame");
		f.setResizable(false);
		f.setSize(720, 250);
		f.setLocation(250, 250);
		f.setDefaultCloseOperation(EXIT_ON_CLOSE);
		f.setVisible(true);

		Container contentPane = f.getContentPane();
		contentPane.setLayout(null);
		contentPane.setBackground(Color.white);

		JMenuBar menuBar = new JMenuBar();
		JMenu file = new JMenu("File");
		menuBar.add(file);
		JMenuItem quit = new JMenuItem("Quit");
		file.add(quit);
		quit.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});

		JMenu edit = new JMenu("Edit");
		menuBar.add(edit);
		JMenuItem erase = new JMenuItem("Erase");
		edit.add(erase);
		erase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				contentPane.setBackground(Color.white);
			}
		});

		JMenu color = new JMenu("Color");
		menuBar.add(color);
		JMenuItem red = new JMenuItem("Red");
		JMenuItem green = new JMenuItem("Green");
		JMenuItem blue = new JMenuItem("Blue");
		JMenuItem pink = new JMenuItem("Pink");
		JMenuItem black = new JMenuItem("Black");
		color.add(red);
		red.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				contentPane.setBackground(Color.red);
				
			}
		});
		color.add(green);
		green.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				contentPane.setBackground(Color.green);
				
			}
		});
		color.add(blue);
		blue.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				contentPane.setBackground(Color.blue);
				
			}
		});
		color.add(pink);
		pink.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				contentPane.setBackground(Color.pink);
				
			}
		});
		color.add(black);
		black.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				contentPane.setBackground(Color.black);
				
			}
		});

		f.setJMenuBar(menuBar);
		f.setDefaultCloseOperation(EXIT_ON_CLOSE);
		f.setVisible(true);

	}

}
