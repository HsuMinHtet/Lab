package FPP_Day_9_1;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Prog7_1 extends JFrame implements ActionListener {

	private static final int FRAME_WIDTH = 720;

	private static final int FRAME_HEIGHT = 250;

	private static final int FRAME_X_ORIGIN = 250;

	private static final int FRAME_Y_ORIGIN = 250;

	private static final int BUTTON_WIDTH = 100;

	private static final int BUTTON_HEIGHT = 40;

	private JButton submitButton;

	private JTextField inputLine1;
	private JTextField inputLine2;
	private JTextField inputLine3;
	private JTextField inputLine4;
	private JTextField inputLine5;

	private JLabel prompt1;
	private JLabel prompt2;
	private JLabel prompt3;
	private JLabel prompt4;
	private JLabel prompt5;
	
	Prog7_1() {
		setTitle("Address Form");
		setResizable(false);
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);

		// register 'Exit upon closing' as a default close operation
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container contentPane = getContentPane();
		contentPane.setLayout(null);
		contentPane.setBackground(Color.white);

		// create and place two buttons on the frame's content pane
		submitButton = new JButton("OK");

		submitButton.setBounds(330, 150, BUTTON_WIDTH, BUTTON_HEIGHT);
		contentPane.add(submitButton);

		submitButton.addActionListener(this);

		inputLine1 = new JTextField();
		inputLine2 = new JTextField();
		inputLine3 = new JTextField();
		inputLine4 = new JTextField();
		inputLine5 = new JTextField();
		
		inputLine1.setBounds(20, 50, 200, 25);
		inputLine2.setBounds(260, 50, 200, 25);
		inputLine3.setBounds(500, 50, 200, 25);
		inputLine4.setBounds(150, 100, 200, 25);
		inputLine5.setBounds(390, 100, 200, 25);
		
		contentPane.add(inputLine1);
		contentPane.add(inputLine2);
		contentPane.add(inputLine3);
		contentPane.add(inputLine4);
		contentPane.add(inputLine5);

		inputLine1.addActionListener(this);
		inputLine2.addActionListener(this);
		inputLine3.addActionListener(this);
		inputLine4.addActionListener(this);
		inputLine5.addActionListener(this);

		prompt1 = new JLabel();
		prompt2 = new JLabel();
		prompt3 = new JLabel();
		prompt4 = new JLabel();
		prompt5 = new JLabel();
		
		prompt1.setText("Name");
		prompt1.setBounds(22, 30, 150, 25);
		prompt2.setText("Street");
		prompt2.setBounds(262, 30, 150, 25);
		prompt3.setText("City");
		prompt3.setBounds(502, 30, 150, 25);
		prompt4.setText("State");
		prompt4.setBounds(152, 80, 150, 25);
		prompt5.setText("Zip");
		prompt5.setBounds(392, 80, 150, 25);
		
		contentPane.add(prompt1);
		contentPane.add(prompt2);
		contentPane.add(prompt3);
		contentPane.add(prompt4);
		contentPane.add(prompt5);

		// register 'Exit upon closing' as a default close operation
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	public static void main(String[] args) {

		Prog7_1 mf = new Prog7_1();
		mf.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		String s="";
		if (event.getSource() instanceof JButton) {
			s=inputLine1.getText()+"\n";
			s+=inputLine2.getText()+"\n";
			s+=inputLine3.getText()+",  ";
			s+=inputLine4.getText()+"  ";
			s+=inputLine5.getText();
			System.out.print(s);
		} else { // the event source is inputLine
			setTitle("You entered '" + inputLine1.getText() + "'");
		}
	}
}
