package FPP_Day_9_1;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

public class Prog7_2_7_3 extends JFrame {

	public static void main(String[] args) {
		JFrame f = new JFrame("String Utility");
		f.setTitle("Address Form");
		f.setResizable(false);
		f.setSize(720, 250);
		f.setLocation(250, 250);
		f.setDefaultCloseOperation(EXIT_ON_CLOSE);
		f.setVisible(true);

		Container contentPane = f.getContentPane();
		contentPane.setLayout(null);
		contentPane.setBackground(Color.white);

		JLabel input = new JLabel();
		input.setText("Input");
		input.setBounds(301, 15, 150, 20);
		contentPane.add(input);

		JLabel output = new JLabel();
		output.setText("Output");
		output.setBounds(301, 85, 150, 20);
		contentPane.add(output);

		JTextField inputText = new JTextField();
		inputText.setBounds(300, 30, 200, 30);
		contentPane.add(inputText);
		inputText.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s = inputText.getText();
				System.out.println(s);
			}
		});

		JTextField outputText = new JTextField();
		outputText.setBounds(300, 100, 200, 30);
		contentPane.add(outputText);
		outputText.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s = outputText.getText();
				System.out.println(s);
			}
		});

		JButton countBtn = new JButton("Count Letters");
		countBtn.setBounds(80, 10, 200, 40);
		contentPane.add(countBtn);
		countBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int length = inputText.getText().length();
				outputText.setText(String.valueOf(length));
			}
		});

		JButton reverseBtn = new JButton("Reverse Letters");
		reverseBtn.setBounds(80, 55, 200, 40);
		contentPane.add(reverseBtn);
		reverseBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s = inputText.getText();
				String reverse = "";
				for (int i = s.length() - 1; i >= 0; i--) {
					reverse += s.charAt(i);
				}
				outputText.setText(reverse);
			}
		});

		JButton removeBtn = new JButton("Remove Duplicates");
		removeBtn.setBounds(80, 100, 200, 40);
		contentPane.add(removeBtn);
		removeBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s = inputText.getText();
				String noDuplicate = "";
				ArrayList<Character> list = new ArrayList<Character>();
				boolean duplicate = false;
				list.add(s.charAt(0));
				for (int i = 0; i < s.length(); i++) {
					duplicate = false;
					for (int j = 0; j < list.size(); j++) {
						if (s.charAt(i) == list.get(j)) {
							duplicate = true;
						}
					}
					if (duplicate == false) {
						list.add(s.charAt(i));
					}
				}
				for (int i = 0; i < list.size(); i++) {
					noDuplicate += list.get(i);
				}
				outputText.setText(noDuplicate);
			}

			private void setText(String string) {
				// TODO Auto-generated method stub

			}
		});

	}

}
