package FPP_Day_9_1;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class MyFrame extends JFrame implements ActionListener {

	/**
	 * Default frame width
	 */
	private static final int FRAME_WIDTH = 300;

	/**
	 * Default frame height
	 */
	private static final int FRAME_HEIGHT = 200;

	/**
	 * X coordinate of the frame default origin point
	 */
	private static final int FRAME_X_ORIGIN = 150;

	/**
	 * Y coordinate of the frame default origin point
	 */
	private static final int FRAME_Y_ORIGIN = 250;
	/**
	 * Default width for buttons
	 */
	private static final int BUTTON_WIDTH = 80;

	/**
	 * Default height for buttons
	 */
	private static final int BUTTON_HEIGHT = 30;

	/**
	 * The Swing button for Cancel
	 */
	private JButton cancelButton;

	/**
	 * The Swing button for OK
	 */
	private JButton okButton;

	/**
	 * The JTextField for the user to enter a text
	 */
	private JTextField inputLine;

	/**
	 * The JLabel for prompting the user
	 */
	private JLabel prompt;

	/**
	 * The JLabel for an image
	 */
	private JLabel image;

	MyFrame() {
		setTitle("My First Subclass");
		setResizable(false);
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);

		// register 'Exit upon closing' as a default close operation
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container contentPane = getContentPane();
		contentPane.setLayout(null);
		contentPane.setBackground(Color.white);

		// create and place two buttons on the frame's content pane
		okButton = new JButton("OK");

		okButton.setBounds(70, 125, BUTTON_WIDTH, BUTTON_HEIGHT);
		contentPane.add(okButton);

		cancelButton = new JButton("CANCEL");
		cancelButton.setBounds(160, 125, BUTTON_WIDTH, BUTTON_HEIGHT);
		contentPane.add(cancelButton);

		// register this frame as an action listener of the two buttons
		cancelButton.addActionListener(this);
		okButton.addActionListener(this);

		inputLine = new JTextField();
		inputLine.setBounds(90, 50, 130, 25);
		contentPane.add(inputLine);

		inputLine.addActionListener(this);

		prompt = new JLabel();
		prompt.setText("Please enter your name");
		// alternative way to create the prompt
		// prompt = new JLabel( "Please enter your name");
		prompt.setBounds(85, 20, 150, 25);

		contentPane.add(prompt);

		image = new JLabel(new ImageIcon("cat.gif"));
		image.setBounds(10, 20, 50, 50);
		contentPane.add(image);

		// register 'Exit upon closing' as a default close operation
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	public static void main(String[] args) {
		MyFrame mf = new MyFrame();
		mf.setVisible(true);
	}

	public void actionPerformed(ActionEvent event) {

		if (event.getSource() instanceof JButton) {
			JButton clickedButton = (JButton) event.getSource();

			String buttonText = clickedButton.getText();

			setTitle("You clicked " + buttonText);

		} else { // the event source is inputLine
			setTitle("You entered '" + inputLine.getText() + "'");
		}
	}

}
