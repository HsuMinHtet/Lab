package reviewPractice1;

public class Checking extends BankAccount {

	private int numberOfChecksWritten;

	public Checking(double balance, long accountNumber) {
		super(balance, accountNumber);
	}

	@Override
	public void getNumberOfChecksWritten(BankAccount acc) {
		String s = "";
		s = "\nAccount Number :" + acc.getAccountNumber() + " ,Balance :" + acc.getBalance() + " , Number of Checking :"
				+ this.numberOfChecksWritten;
		System.out.print(s);
	}

	public void setNumberOfChecksWritten(int numberOfChecksWritten) {
		this.numberOfChecksWritten = numberOfChecksWritten;
	}

	public int getChecksNumber() {
		return this.numberOfChecksWritten;
	}
}
