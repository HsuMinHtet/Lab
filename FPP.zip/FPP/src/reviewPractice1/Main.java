package reviewPractice1;

import java.util.*;

public class Main {

	static List<BankAccount> arr = new ArrayList<BankAccount>();

	static double totalBalanceForAllAccounts() {
		double totalBalance = 0.0;
		for (BankAccount acc : arr) {
			totalBalance += acc.getBalance();
		}
		return totalBalance;
	}

	static void printCheckingData() {
		String s = "";
		for (BankAccount acc : arr) {
			// if (acc instanceof Checking) {
			// Checking ch = (Checking) acc;
			// s = "\nAccount Number :" + acc.getAccountNumber() + " ,Balance :" +
			// acc.getBalance()
			// + " , Number of Checking :" + ch.getNumberOfChecksWritten();
			acc.getNumberOfChecksWritten(acc);
			// }
		}
		System.out.println("\n");

	}

	static void printAllBankAccountsData(List<BankAccount> arr) {
		String s = "";
		for (BankAccount acc : arr) {
			s = "Account Number :" + acc.getAccountNumber() + " , Balance :" + acc.getBalance();
			if (acc.getChecksNumber() != 0) {
				s += " , Checking Account Number: " + acc.getChecksNumber();
			}
			System.out.println(s);
		}

	}

	public static void main(String[] args) {
		Savings sav = new Savings(100, 111);
		Checking check1 = new Checking(200, 222);
		Checking check2 = new Checking(300, 333);

		check1.setNumberOfChecksWritten(8);
		check2.setNumberOfChecksWritten(3);

		// List<BankAccount> arr = new ArrayList<BankAccount>();
		arr.add(sav);
		arr.add(check1);
		arr.add(check2);

		System.out.printf("Total Balance: %,.2f", Main.totalBalanceForAllAccounts());
		System.out.println("\n");
		Main.printCheckingData();
		Main.printAllBankAccountsData(arr);
	}

}
