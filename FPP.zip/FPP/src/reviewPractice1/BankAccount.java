package reviewPractice1;

public abstract class BankAccount {

	private double balance;
	private long accountNumber;

	public BankAccount(double balance, long accountNumber) {
		this.balance = balance;
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public abstract void getNumberOfChecksWritten(BankAccount acc);
	
	public int getChecksNumber() {return 0;}
}
