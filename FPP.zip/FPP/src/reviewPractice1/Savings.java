package reviewPractice1;

public class Savings extends BankAccount{

	public Savings(double balance, long accountNumber) {
		super(balance, accountNumber);
	}

	@Override
	public void getNumberOfChecksWritten(BankAccount acc) {
		
	}

}
