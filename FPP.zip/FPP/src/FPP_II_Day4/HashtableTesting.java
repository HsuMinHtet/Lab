package FPP_II_Day4;

import java.util.*;
import java.util.LinkedList;

public class HashtableTesting {

	private static final int INITIAL_SIZE=19;
	private int tableSize;
	private LinkedList[] table;

	public HashtableTesting() {
		this(INITIAL_SIZE);
	}

	public HashtableTesting(int tableSize) {
		this.tableSize = tableSize;
		table = new LinkedList[tableSize];
	} // an array of LinkedList objects.

	public void put(Object key, Object value) {
		if(key==null)
			return;
		if(get(key)!=null) {
			System.out.println("Duplicate");
			return;
		}
		int hashCode= key.hashCode();
		int hash= Math.abs(hashM(hashCode));
		Entry e= new Entry(key, value);
		if(table[hash]==null) {
			table[hash]=new LinkedList();
		}
		table[hash].add(e);
	}

	public Object get(Object key) {
		if(key==null)
			return null;
		int hashCode=key.hashCode();
		int hash=Math.abs(hashM(hashCode));
		Entry e= null;
		if(table[hash]!=null) {
			Iterator it= table[hash].iterator();
			while(it.hasNext()) {
				e=(Entry) it.next();
				if(e.key.equals(key))
					return e.value;
			}
		}
		return null;
	}

	public String toString() {
		StringBuffer sb= new StringBuffer();
		for(int i=0; i<table.length; i++) {
			if(table[i]!=null) {
				Iterator it=table[i].iterator();
				Entry e= null;
				while(it.hasNext()) {
					e=(Entry)it.next();
					sb.append( e.key+", ");
				}
			}
		}
		return sb.toString();
	}

	public int countElements() {
		int count = 0;
		if (table == null)
			return 0;
		for (int i = 0; i < table.length; i++) {
			if (table[i] != null) {
				Iterator<String> it = table[i].iterator();
				while (it.hasNext()) {
					it.next();
					count++;
				}
			}
		}
		return count;
	}

	public int longestElementCount() {
		int count = 0, longest = 0;
		if (table == null)
			return 0;
		for (int i = 0; i < table.length; i++) {
			if (table[i] != null) {
				count = 0;
				// System.out.println("Table"+i +"Size"+table[i].size());
				Iterator it = table[i].iterator();
				while (it.hasNext()) {
					it.next();
					count++;
				}
				if (longest < count) {
					longest = count;
				}
			}
		}
		return longest;
	}

	public int countEmpty() {
		int count = 0;
		for (int i = 0; i < table.length; i++) {
			if (table[i] == null)
				count++;
		}
		return count;
	}

//In the java file this method might be called hash
	private int hashM(int bigNum) {
		return bigNum % tableSize;
	}

	private class Entry {
		private Object key;
		private Object value;

		Entry(Object key, Object value) {
			this.key = key;
			this.value = value;
		}

		public String toString() {
			return key.toString() + "->" + value.toString();
		}

	}

	public static void main(String[] args) {

		HashtableTesting myHash = new HashtableTesting();
		myHash.put("John", 641 - 472 - 1111);
		myHash.put("Smith", 641 - 472 - 2222);
		myHash.put("Mith", 641 - 472 - 3333);
		myHash.put("Julie", 641 - 472 - 4444);
		myHash.put("Shyla", 641 - 444 - 1111);
		myHash.put("Sara", 641 - 222 - 1111);
		myHash.put("Wood", 641 - 666 - 1111);
		myHash.put("Amy", 641 - 777 - 1111);
		myHash.put("Honey", 641 - 111 - 1111);
		myHash.put("Will", 641 - 572 - 1111);

		System.out.println(myHash.toString());
		System.out.println("No of elements in LinkedList	:" + myHash.countElements());
		System.out.println("Empty Count in Hash Table	:" + myHash.countEmpty());
		System.out.println("Longest LinkedList Chain		:" + myHash.longestElementCount());
	}

}
