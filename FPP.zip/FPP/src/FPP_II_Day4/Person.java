package FPP_II_Day4;

public class Person {
	private String name;
	private String phno;
	public Person() {
		
	}
	public Person(String name, String phno) {
		this.name=name;
		this.phno=phno;
	}
	public String getName() {
		return name;
	}
	public String getPhno() {
		return phno;
	}

}
