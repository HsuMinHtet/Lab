package FPP_II_Day4;

public class Main {

	public static void main(String[] args) {
		MyHashtable hashTable = new MyHashtable();
		hashTable.put("John Smith", new Person("John Smith", "641-472-1111"));
		hashTable.put("Julie Woods", new Person("Julie Woods", "641-472-2222"));
		hashTable.put("Amily", new Person("Amily", "641-343-2222"));
		hashTable.put("Candy", new Person("Candy", "641-111-2222"));
		hashTable.put("Katy", new Person("Katy", "641-333-33333"));
		hashTable.put("Caty", new Person("Caty", "641-333-2222"));
		hashTable.put("Caty", new Person("Caty", "641-333-2222"));

		System.out.println(hashTable);
		System.out.println("No of elements in LinkedList	:" + hashTable.countData());
		System.out.println("Empty Count in Hash Table	:" + hashTable.countNull());
		System.out.println("Longest LinkedList Chain		:" + hashTable.countLongest());
		
	}

}
