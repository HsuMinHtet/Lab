package FPP_Day6;

public class Review {

	static int CountTotalNumberOfLetter(String s1) {
		int count = 0;
		for (int i = 0; i < s1.length(); i++) {
			//if ((s1.charAt(i) >= 'a' && s1.charAt(i) <= 'z') || ((s1.charAt(i) >= 'A' && s1.charAt(i) <= 'Z'))) {
			if(Character.isLetter(s1.charAt(i))) {	
			count++;
			}
		}
		return count;
	}

	static void GetAvrage() {
		int num = 0, sum = 0;
		double allAvg = 0.0;
		int[][] arr1 = new int[5][10];
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr1[i].length; j++) {
				arr1[i][j] = num++;
			}
		}
		// AllAvg
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr1[i].length; j++) {
				sum += arr1[i][j];
			}
		}
		allAvg = sum / (arr1.length * arr1[0].length);
		System.out.printf("\nAverage of all values: %.2f", allAvg);

		// Avg for rows no.3
			for (int j = 0; j < arr1[2].length; j++) {
				sum += arr1[2][j];
			}
		allAvg = sum / (1 * arr1[2].length);
		System.out.printf("\nAverage row no3: %.2f", allAvg);
	}

	public static void main(String[] args) {
		System.out.print(CountTotalNumberOfLetter("Test this No.1"));
		GetAvrage();
	}

}
