package standardExamPractice_3;

public final class SavingsAccount extends Account {
	double balance;
	double interestRate;

	public SavingsAccount(double balance, double interestRate) {
		this.balance = balance;
		this.interestRate = interestRate;
	}

	public double getBalance() {
		double newbalance = balance + interestRate * balance;
		return newbalance;
	}

}
