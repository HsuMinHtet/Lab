package standardExamPractice_3;

import java.util.List;

public class AccountManager {
	public static double computeAccountBalanceSum(List<Employee> emps) {
		double total=0.0;
		for(Employee e:emps) {
			List<Account> acc= e.getAccounts();
			for(int i=0; i<acc.size();i++) {
				total+=acc.get(i).getBalance();
			}
		}
		System.out.printf("Total Balance %,.2f", total);
		return total;
	}
}
