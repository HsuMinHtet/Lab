package standardExamPractice_3;

public abstract class Account {
	public abstract double getBalance();
}
