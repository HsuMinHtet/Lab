package FPP_II_Day5_5_2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		Employee e1 = new Employee("BBB", 5);
		Employee e2 = new Employee("AAA", 1);
		Employee e3 = new Employee("CCC", 3);
		e1.setSsn("145-55-2554");
		e2.setSsn("011-83-2334");
		e3.setSsn("265-00-2315");

		list.add(e1);
		list.add(e2);
		list.add(e3);

		System.out.println("Before sort: ");
		for (int i = 0; i < list.size(); i++) {
			Employee e = (Employee) list.get(i);
			System.out.println(e.getName());
		}

		Collections.sort(list, Employee.NAME);

		System.out.println("After sort by Name: ");
		for (int i = 0; i < list.size(); i++) {
			Employee e = (Employee) list.get(i);
			System.out.println(e.getName());
		}

		Collections.sort(list, Employee.AGE);

		System.out.println("After sort by Age: ");
		for (int i = 0; i < list.size(); i++) {
			Employee e = (Employee) list.get(i);
			System.out.println(e.getName());
		}

		Collections.sort(list, new SsnComparator());
		System.out.println("After sort by SSN: ");
		for (int i = 0; i < list.size(); i++) {
			Employee e = (Employee) list.get(i);
			System.out.println(e.getName());
		}

	}

}

/*
 * The ouput looks like the following with some minor changes to the text Every
 * time it compares 2 items the comparator method is called!! JL 07-2011
 * 
 * Before sort: BBB AAA CCC Name comparator is Employee$1 class Employee$1 Name
 * comparator is Employee$1 class Employee$1 After sort by Name: AAA BBB CCC Age
 * Comparator is class Employee$2 Age Comparator is __ Employee$2 Age Comparator
 * is class Employee$2 Age Comparator is __ Employee$2 Age Comparator is class
 * Employee$2 Age Comparator is __ Employee$2 After sort by Age: AAA CCC BBB
 * 
 */