package FPP_II_Day5_5_2;

import java.util.Comparator;

//An Easier way to write a Comparator!

public class SsnComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		Employee e1 = (Employee) o1;
		Employee e2 = (Employee) o2;
		String ssn1 = e1.getSsn();
		String ssn2 = e2.getSsn();

		ssn1.replaceAll("-", "");
		ssn2.replaceAll("-", "");

		return ssn1.compareTo(ssn2);
	}

}
