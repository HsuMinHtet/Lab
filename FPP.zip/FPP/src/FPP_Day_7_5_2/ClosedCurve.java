package FPP_Day_7_5_2;
abstract public class ClosedCurve {
	abstract double computeArea();

}
