package FPP_Day_7_5_2;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		List<ClosedCurve> objects = new ArrayList<ClosedCurve>();
		objects.add( new Triangle(4, 5, 6));
		objects.add(new Square(3));
		objects.add(new Circle(3));
		objects.add(new Rectangle(2, 2));

		String s = "The area of this ";
		// compute areas
		/*
		for (ClosedCurve cc : objects) {
			if (cc instanceof Circle) {
				s += "Circle is ";
			}
			if (cc instanceof Triangle) {
				s += "Triangle is ";
			}
			if (cc.getClass().getSimpleName().equals("Rectangle")) {
				s += "Rectangle is ";
			}
			if (cc.getClass() == Square.class) {
				s += "Square is ";
			}
			System.out.printf(s + "%f%n", cc.computeArea());
			s = "The area of this ";
			System.out.println(cc.getClass().getName());
		}		
*/
		
		for (int i=0; i<objects.size(); i++) {
			if (objects.get(i).getClass()== Circle.class) {
				s += objects.get(i).getClass().getSimpleName()+" is ";
			}
			if (objects.get(i).getClass() == Triangle.class) {
				s += "Triangle is ";
			}
			if (objects.get(i).getClass() == Rectangle.class) {
				s += "Rectangle is ";
			}
			if (objects.get(i).getClass()== Square.class) {
				s += "Square is ";
			}
			System.out.printf(s + "%.2f\n", objects.get(i).computeArea());
			s = "The area of this ";
		}
		
		
	}

}