module FPP {
	requires java.desktop;
	requires java.xml;
}