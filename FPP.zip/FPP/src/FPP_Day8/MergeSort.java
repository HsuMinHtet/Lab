package FPP_Day8;

import java.util.Arrays;

public class MergeSort {

	public static void main(String[] args) {
		int[] arr1 = { 1, 5, 3, 7, 9, 11, 13 };
		int[] arr2 = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };
		MergeSort m = new MergeSort();
		int[] result = m.merge(arr1, arr2);
		
		System.out.print(Arrays.toString(result));
	}

	public int[] merge(int[] arr1, int[] arr2) {
		if (arr1 == null)
			return arr2;
		if (arr2 == null)
			return arr1;
		int len1 = arr1.length;
		int len2 = arr2.length;
		int[] retVal = new int[len1 + len2];

		return recursiveMerge(retVal, 0, arr1, arr2);
	}

	private int[] recursiveMerge(int[] returnVal, int nextAvailPos, int[] first, int[] second)

	{
		// base (if no elements in First array)
		if (first.length == 0) {
			System.arraycopy(second, 0, returnVal, nextAvailPos, second.length);
			return returnVal;
		}
		// base (if no elements in Second array)
		if (second.length == 0) {
			System.arraycopy(first, 0, returnVal, nextAvailPos, first.length);
			return returnVal;
		}

		if (first[0] <= second[0]) {
			returnVal[nextAvailPos] = first[0];
			return recursiveMerge(returnVal, nextAvailPos + 1, remove0th(first), second);
		} else {
			returnVal[nextAvailPos] = second[0];
			return recursiveMerge(returnVal, nextAvailPos + 1, first, remove0th(second));
		}
	}

	private int[] remove0th(int[] arr) {
		int[] removeArr = new int[arr.length - 1];
		for (int i = 1; i < arr.length; i++) {
			removeArr[i - 1] = arr[i];
		}
		return removeArr;
	}

}
