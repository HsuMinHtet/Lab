package FPP_Day8;

public class Fibonacci {

	public static void main(String[] args) {
		Fibonacci fac = new Fibonacci();
		System.out.println("Fibonacci for '" + 5 + "' is :" + fac.getFibonacci(6));

	}

	static int getFibonacci(int n) {
		if (n == 1 || n == 0)
			return n;
		else
			return getFibonacci(n - 1) + getFibonacci(n - 2);
	}

}
