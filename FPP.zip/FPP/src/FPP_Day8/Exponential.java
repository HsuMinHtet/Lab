package FPP_Day8;

public class Exponential {

	public static void main(String[] args) {
		Exponential exp = new Exponential();
		System.out.println("Exponential for '2' Power '10' is :" +exp.power(2, 5));
	}

	double power(double x, int n) {
		// base
		if (n == 0) {
			return 1;
		} else
			return x * power(x, n - 1);
	}

}
