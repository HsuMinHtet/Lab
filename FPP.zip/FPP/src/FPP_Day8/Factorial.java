package FPP_Day8;

public class Factorial {
	public static void main(String[] args) {
		Factorial fac = new Factorial();
		System.out.println("Factorial for '" + 5 + "' is :" + fac.getFactorial(5));
	}

	int getFactorial(int n) {
		// base
		if (n == 0 || n == 1) {
			return 1;
		} else
			return n * getFactorial(n - 1);
	}
}
