package FPP_Day8;

import java.io.File;

public class FileSearch {

	public static void main(String[] args) {
		searchFileRecursively(null, null);

	}

	public static void searchFileRecursively(String path, String filename) {
		File file = new File(path + filename);
		if (file.exists()) {
			System.out.println("Found file: " + file.getAbsolutePath());
		} else {
			for (File child : file.listFiles()) {
				searchFileRecursively(child.getParent(), filename);
			}
		}
	}
}
