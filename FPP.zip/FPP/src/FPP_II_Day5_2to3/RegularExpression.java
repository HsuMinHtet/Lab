package FPP_II_Day5_2to3;

import java.util.Scanner;

public class RegularExpression {
	//license plate number format
	//two letters followed by four digits followed by three letters
	private static final String VALID_IDENTIFIER_PATTERN = "[a-zA-Z]{2}[0-9]{4}[a-zA-Z]{3}";

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter license");
		String s = sc.nextLine();
		if(s.matches(VALID_IDENTIFIER_PATTERN))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		System.out.println("Enter sentence including 'eight' to replace");
		 s = sc.nextLine();
		System.out.println(s.replaceAll("eight", "8"));
			 
	}

}
