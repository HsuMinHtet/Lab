package FPP_Day_5_2;

public class Test {

	public static void main(String[] args) {

		ClosedCurve[] objects = { new Triangle(4, 5, 6), new Square(3), new Circle(3) , new Rectangle(2,2)};
		
		String s="";
		
		for(ClosedCurve c: objects) {
			s= "The area of this "+ c.getClass().getSimpleName() + " is :  ";
			System.out.printf(s+"%.2f\n", c.computeArea());
		}
		/*
		// compute areas
		for (ClosedCurve cc : objects) {
			if(cc instanceof Circle) {
				s+="Circle is ";
			}
			if(cc instanceof Triangle) {
				s+="Triangle is ";
			}
			if(cc instanceof Rectangle) {
				s+="Rectangle is ";
			}
			if(cc instanceof Square) {
				s+="Square is ";
			}
			System.out.printf(s+"%f%n", cc.computeArea());
			s="The area of this ";
		}*/

	}

}