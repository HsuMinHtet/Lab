package FPP_Day_5_2;

public class Rectangle extends ClosedCurve{
	private double widht;
	private double height;
	
	public Rectangle(double widht, double height) {
		this.widht = widht;
		this.height = height;
	}
	
	double computeArea() {
		return widht * height;
	}
}
