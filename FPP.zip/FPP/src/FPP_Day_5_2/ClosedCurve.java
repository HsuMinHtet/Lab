package FPP_Day_5_2;
abstract public class ClosedCurve {
	abstract double computeArea();

}
